import express from 'express';
import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import cors from 'cors';  // 需要安装

const app = express();
app.use(express.json());

// ==================== CORS配置（关键） ====================
app.use(cors({
  origin: ['http://localhost:3426'],  // 允许前端访问
  methods: ['GET', 'POST', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

// ==================== 核心配置 ====================
const PORT = 3425;
const TARGET_BASE = 'https://api.siliconflow.cn/v1';
const DATA_DIR = path.resolve('./data');
const KEYS_FILE = path.join(DATA_DIR, 'keys.json');
const LOGS_FILE = path.join(DATA_DIR, 'logs.json');

// 允许的模型（全大小写兼容）
const ALLOWED_MODELS = new Set([
  'deepseek-ai/deepseek-R1',
  'deepseek-ai/deepseek-V2.5',
  'deepseek-ai/deepseek-V3',
  'Pro/MiniMaxAI/MiniMax-M2.5'
]);

// 客户端获取模型列表
const MODELS_LIST = [
  { id: '充值/购买请联系', object: 'model', created: 1, owned_by: 'deepseek-ai' },
  { id: 'deepseek-ai/deepseek-R1', object: 'model', created: 1, owned_by: 'deepseek-ai' },
  { id: 'deepseek-ai/deepseek-V2.5', object: 'model', created: 1, owned_by: 'deepseek-ai' },
  { id: 'deepseek-ai/deepseek-V3', object: 'model', created: 1, owned_by: 'deepseek-ai' },
   { id: 'Pro/MiniMaxAI/MiniMax-M2.5', object: 'model', created: 1, owned_by: 'MiniMaxAI' }
];

// 精准计费规则（元/千tokens）
const PRICING = {
  'deepseek-ai/deepseek-R1': { input: 0.008, output: 0.020 },
  'deepseek-ai/deepseek-r1': { input: 0.008, output: 0.020 },
  'deepseek-ai/deepseek-V2.5': { input: 0.0177, output: 0.0188 },
  'deepseek-ai/deepseek-v2.5': { input: 0.0177, output: 0.0188 },
  'deepseek-ai/deepseek-V3': { input: 0.004, output: 0.010 },
  'deepseek-ai/deepseek-v3': { input: 0.004, output: 0.010 },
  'Pro/MiniMaxAI/MiniMax-M2.5': { input: 0.0121, output: 0.0184 }

};

// ==================== 工具函数 ====================
const initDataFiles = () => {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(KEYS_FILE)) fs.writeFileSync(KEYS_FILE, JSON.stringify({}));
  if (!fs.existsSync(LOGS_FILE)) fs.writeFileSync(LOGS_FILE, JSON.stringify([]));
};

const readJSON = (filePath) => {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(content);
  } catch (e) {
    console.error('读取文件失败:', e);
    return filePath === KEYS_FILE ? {} : [];
  }
};

const writeJSON = (filePath, data) => {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    return true;
  } catch (e) {
    console.error('写入文件失败:', e);
    return false;
  }
};

const normalizeModel = (modelName) => {
  const lowerName = modelName.toLowerCase();
  if (lowerName.includes('r1')) return 'deepseek-ai/deepseek-R1';
  if (lowerName.includes('v2.5')) return 'deepseek-ai/deepseek-V2.5';
  if (lowerName.includes('v3')) return 'deepseek-ai/deepseek-V3';
  if (lowerName.includes('M2.5')) return 'Pro/MiniMaxAI/MiniMax-M2.5';
  return modelName;
};

// 精准计算费用（修复浮点误差，保留6位小数）
const calculateCost = (model, inputTokens, outputTokens) => {
  const price = PRICING[model];
  if (!price || inputTokens < 0 || outputTokens < 0) return 0;
  const inputCost = (inputTokens / 1000) * price.input;
  const outputCost = (outputTokens / 1000) * price.output;
  return Math.round((inputCost + outputCost) * 1000000) / 1000000;
};

// 解析SSE流式chunk，提取usage token数
const parseSSEChunk = (chunkStr) => {
  const lines = chunkStr.split('\n').filter(line => line.trim() && line.startsWith('data: '));
  let inputTokens = 0;
  let outputTokens = 0;
  let isDone = false;

  for (const line of lines) {
    const content = line.slice(6).trim();
    if (content === '[DONE]') {
      isDone = true;
      continue;
    }
    try {
      const data = JSON.parse(content);
      if (data.usage) {
        inputTokens = data.usage.prompt_tokens || 0;
        outputTokens = data.usage.completion_tokens || 0;
      }
    } catch (e) {}
  }
  return { inputTokens, outputTokens, isDone };
};

// ==================== 中间件 ====================
const authMiddleware = (req, res, next) => {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ error: { message: '你的Key不存在或未授权', type: 'auth_error' } });
  }
  const clientKey = auth.split(' ')[1].trim();
  const keys = readJSON(KEYS_FILE);

  if (!keys[clientKey]) {
    return res.status(401).json({ error: { message: '你的Kye不存在或未授权', type: 'auth_error' } });
  }
  // 余额≤0直接拦截
  if (keys[clientKey].balance <= 0) {
    return res.status(402).json({ error: { message: '余额不足，请充值 2538295233', type: 'payment_error' } });
  }

  req.clientKey = clientKey;
  req.keyInfo = keys[clientKey];
  next();
};

const modelCheckMiddleware = (req, res, next) => {
  const model = req.body.model;
  if (!model || !ALLOWED_MODELS.has(model)) {
    return res.status(400).json({ error: { message: '不在列表的模型 拒绝使用', type: 'model_error' } });
  }
  req.normalizedModel = normalizeModel(model);
  next();
};

// ==================== API路由 ====================

// 1. 模型列表（OpenAI兼容）
app.get('/v1/models', (req, res) => {
  res.json({ object: 'list', data: MODELS_LIST });
});

// 2. 余额查询接口（修复404的关键）
app.get('/v1/credits', authMiddleware, (req, res) => {
  res.json({
    data: {
      total_usage: req.keyInfo.balance  // 兼容OpenAI格式
    },
    balance: req.keyInfo.balance  // 也返回我们自己的格式
  });
});

// 3. 聊天反代（核心计费逻辑）
app.post('/v1/chat/completions', authMiddleware, modelCheckMiddleware, async (req, res) => {
  try {
    const requestBody = req.body;
    const isStream = requestBody.stream === true;
    const { clientKey, normalizedModel } = req;

    const upstreamResp = await fetch(`${TARGET_BASE}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': req.headers.authorization,
        'Content-Type': 'application/json',
        'Accept': isStream ? 'text/event-stream' : 'application/json'
      },
      body: JSON.stringify(requestBody),
      timeout: 120000
    })
    
    if (!upstreamResp.ok) {
      const errorData = await upstreamResp.json().catch(() => ({ message: 'Upstream request failed' }));
      return res.status(upstreamResp.status).json(errorData);
    }


    // 流式响应处理
    if (isStream) {
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');

      let totalInput = 0;
      let totalOutput = 0;

      upstreamResp.body.on('data', (chunk) => {
        const chunkStr = chunk.toString();
        const { inputTokens, outputTokens } = parseSSEChunk(chunkStr);
        if (inputTokens > 0) totalInput = inputTokens;
        if (outputTokens > 0) totalOutput = outputTokens;
        res.write(chunk);
      });

      upstreamResp.body.on('end', () => {
        const cost = calculateCost(normalizedModel, totalInput, totalOutput);
        const keys = readJSON(KEYS_FILE);
        const logs = readJSON(LOGS_FILE);

        if (keys[clientKey]) {
          keys[clientKey].balance = Math.max(0, Math.round((keys[clientKey].balance - cost) * 1000000) / 1000000);
          keys[clientKey].totalUsed = Math.round((keys[clientKey].totalUsed + cost) * 1000000) / 1000000;
          writeJSON(KEYS_FILE, keys);
        }

        logs.unshift({
          time: new Date().toLocaleString('zh-CN'),
          key: clientKey,
          model: normalizedModel,
          inputTokens: totalInput,
          outputTokens: totalOutput,
          cost: Number(cost.toFixed(6)),
          costShow: Number(cost.toFixed(4))
        });
        writeJSON(LOGS_FILE, logs);
        res.end();
      });

      upstreamResp.body.on('error', (err) => {
        console.error('Stream error:', err);
        res.end();
      });

    } else {
      // 非流式处理
      const responseData = await upstreamResp.json();
      const inputTokens = responseData.usage?.prompt_tokens || 0;
      const outputTokens = responseData.usage?.completion_tokens || 0;
      const cost = calculateCost(normalizedModel, inputTokens, outputTokens);

      const keys = readJSON(KEYS_FILE);
      const logs = readJSON(LOGS_FILE);
      
      if (keys[clientKey]) {
        keys[clientKey].balance = Math.max(0, Math.round((keys[clientKey].balance - cost) * 1000000) / 1000000);
        keys[clientKey].totalUsed = Math.round((keys[clientKey].totalUsed + cost) * 1000000) / 1000000;
        writeJSON(KEYS_FILE, keys);
      }

      logs.unshift({
        time: new Date().toLocaleString('zh-CN'),
        key: clientKey,
        model: normalizedModel,
        inputTokens: inputTokens,
        outputTokens: outputTokens,
        cost: Number(cost.toFixed(6)),
        costShow: Number(cost.toFixed(4))
      });
      writeJSON(LOGS_FILE, logs);

      res.json(responseData);
    }

  } catch (err) {
    console.error('Proxy error:', err);
    res.status(500).json({ error: { message: 'Proxy server error', type: 'server_error' } });
  }
});

// ==================== 管理后台API（供前端调用） ====================

// 获取所有数据（Keys + Logs）
app.get('/admin/api/data', (req, res) => {
  // 可以添加简单的IP白名单或token验证，这里先开放
  res.json({
    keys: readJSON(KEYS_FILE),
    logs: readJSON(LOGS_FILE)
  });
});

// 添加/充值Key
app.post('/admin/api/key', (req, res) => {
  const { key, balance } = req.body;
  if (!key || balance == null || isNaN(balance) || balance < 0) {
    return res.status(400).json({ error: '无效参数' });
  }
  
  const keys = readJSON(KEYS_FILE);
  if (keys[key]) {
    // 充值
    keys[key].balance = Math.round((keys[key].balance + Number(balance)) * 1000000) / 1000000;
  } else {
    // 新增Key
    keys[key] = {
      balance: Math.round(Number(balance) * 1000000) / 1000000,
      totalUsed: 0,
      createTime: new Date().toISOString()
    };
  }
  writeJSON(KEYS_FILE, keys);
  res.json({ success: true, balance: keys[key].balance });
});

// 删除Key
app.delete('/admin/api/key/:key', (req, res) => {
  const { key } = req.params;
  const keys = readJSON(KEYS_FILE);
  delete keys[key];
  writeJSON(KEYS_FILE, keys);
  res.json({ success: true });
});

// ==================== 启动 ====================
initDataFiles();
app.listen(PORT, '0.0.0.0', () => {
});
