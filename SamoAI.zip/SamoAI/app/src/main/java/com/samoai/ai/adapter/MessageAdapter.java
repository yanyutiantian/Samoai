package com.samoai.ai.adapter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.samoai.ai.model.Message;
import com.samoai.ai.utils.AnimUtils;
import com.samoai.ai.utils.UiUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 消息列表适配器
 */
public class MessageAdapter extends BaseAdapter {
    
    private Context context;
    private List<Message> messages;
    private OnMessageLongClickListener longClickListener;
    
    // Kimi风格颜色
    private static final int COLOR_USER_BG = Color.parseColor("#10A37F");
    private static final int COLOR_AI_BG = Color.parseColor("#F7F7F8");
    private static final int COLOR_USER_TEXT = Color.WHITE;
    private static final int COLOR_AI_TEXT = Color.parseColor("#374151");
    private static final int COLOR_SYSTEM_TEXT = Color.parseColor("#9CA3AF");
    
    public interface OnMessageLongClickListener {
        void onMessageLongClick(Message message, int position);
    }
    
    public MessageAdapter(Context context) {
        this.context = context;
        this.messages = new ArrayList<Message>();
    }
    
    public void setOnMessageLongClickListener(OnMessageLongClickListener listener) {
        this.longClickListener = listener;
    }
    
    public void setMessages(List<Message> messages) {
        this.messages = messages != null ? messages : new ArrayList<Message>();
        notifyDataSetChanged();
    }
    
    public void addMessage(Message message) {
        if (message != null) {
            messages.add(message);
            notifyDataSetChanged();
        }
    }
    
    public void updateMessage(Message message) {
        if (message == null) return;
        
        for (int i = 0; i < messages.size(); i++) {
            if (messages.get(i).getId().equals(message.getId())) {
                messages.set(i, message);
                notifyDataSetChanged();
                break;
            }
        }
    }
    
    public void updateLastMessage(String content) {
        if (messages.isEmpty()) return;
        
        Message lastMsg = messages.get(messages.size() - 1);
        lastMsg.setContent(content);
        notifyDataSetChanged();
    }
    
    public List<Message> getMessages() {
        return new ArrayList<Message>(messages);
    }
    
    public void clear() {
        messages.clear();
        notifyDataSetChanged();
    }
    
    @Override
    public int getCount() {
        return messages.size();
    }
    
    @Override
    public Object getItem(int position) {
        return messages.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return position;
    }
    
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        MessageViewHolder holder;
        
        if (convertView == null) {
            holder = new MessageViewHolder();
            holder.container = createMessageContainer();
            holder.bubble = createMessageBubble();
            holder.contentView = createContentView();
            
            holder.bubble.addView(holder.contentView);
            holder.container.addView(holder.bubble);
            convertView = holder.container;
            convertView.setTag(holder);
        } else {
            holder = (MessageViewHolder) convertView.getTag();
        }
        
        final Message message = messages.get(position);
        bindMessage(holder, message, position);
        
        // 长按复制
        holder.bubble.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (longClickListener != null) {
                    longClickListener.onMessageLongClick(message, position);
                    return true;
                }
                return false;
            }
        });
        
        // 新消息添加动画
        if (position == messages.size() - 1 && message.isStreaming()) {
          //  AnimUtils.messageAppear(holder.container);
        }
        
        return convertView;
    }
    
    private LinearLayout createMessageContainer() {
        LinearLayout container = new LinearLayout(context);
        container.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        container.setPadding(
            UiUtils.dpToPx(context, 12),
            UiUtils.dpToPx(context, 6),
            UiUtils.dpToPx(context, 12),
            UiUtils.dpToPx(context, 6)
        );
        return container;
    }
    
    private LinearLayout createMessageBubble() {
        LinearLayout bubble = new LinearLayout(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.weight = 0;
        bubble.setLayoutParams(params);
        bubble.setOrientation(LinearLayout.VERTICAL);
        int padding = UiUtils.dpToPx(context, 12);
        bubble.setPadding(padding, padding, padding, padding);
        return bubble;
    }
    
    private TextView createContentView() {
        TextView textView = new TextView(context);
        textView.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        textView.setTextSize(15);
        textView.setLineSpacing(UiUtils.dpToPx(context, 4), 1f);
        return textView;
    }
    
    private void bindMessage(MessageViewHolder holder, Message message, int position) {
        LinearLayout container = holder.container;
        LinearLayout bubble = holder.bubble;
        TextView contentView = holder.contentView;
        
        // 设置内容
        contentView.setText(message.getContent());
        
        // 根据消息类型设置样式
        if (message.getType() == Message.TYPE_USER) {
            // 用户消息 - 右侧，绿色背景
            container.setGravity(Gravity.RIGHT);
            bubble.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
                COLOR_USER_BG, 16, context));
            contentView.setTextColor(COLOR_USER_TEXT);
            
            // 设置最大宽度
            int maxWidth = (int) (UiUtils.getScreenWidth(context) * 0.75);
            bubble.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ));
            contentView.setMaxWidth(maxWidth);
            
        } else if (message.getType() == Message.TYPE_AI) {
            // AI消息 - 左侧，灰色背景
            container.setGravity(Gravity.LEFT);
            bubble.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
                COLOR_AI_BG, 16, context));
            contentView.setTextColor(COLOR_AI_TEXT);
            
            int maxWidth = (int) (UiUtils.getScreenWidth(context) * 0.85);
            contentView.setMaxWidth(maxWidth);
            
        } else {
            // 系统消息 - 居中
            container.setGravity(Gravity.CENTER);
            bubble.setBackgroundDrawable(null);
            contentView.setTextColor(COLOR_SYSTEM_TEXT);
            contentView.setTextSize(12);
        }
    }
    
    private static class MessageViewHolder {
        LinearLayout container;
        LinearLayout bubble;
        TextView contentView;
    }
}
