package com.samoai.ai.api;

/**
 * 流式输出回调接口
 */
public interface StreamCallback {
    /**
     * 收到新的内容片段
     */
    void onContent(String content);
    
    /**
     * 流式输出完成
     */
    void onComplete();
    
    /**
     * 发生错误
     */
    void onError(String error);
}
