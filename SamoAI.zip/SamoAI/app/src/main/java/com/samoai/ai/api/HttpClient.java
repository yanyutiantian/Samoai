package com.samoai.ai.api;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONArray;
import org.json.JSONObject;

import com.samoai.ai.model.Message;

import java.util.List;

/**
 * HTTP客户端 - 处理API请求（修复DeepSeek R1思考逐字输出问题）
 */
public class HttpClient {
    private static HttpClient instance;
    private ExecutorService executorService;
    private String apiKey;
   /**
     * 考内容缓存，用于累积DeepSeek R1的reasoning_content
     */
    private StringBuilder reasoningBuffer = new StringBuilder();
    /** 标记是否正在输出思考内容
      *
      */
    private boolean isInReasoning = false;

    private HttpClient() {
        executorService = Executors.newCachedThreadPool();
    }

    public static synchronized HttpClient getInstance() {
        if (instance == null) {
            instance = new HttpClient();
        }
        return instance;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }

    public String getApiKey() {
        return apiKey;
    }

    /**
     *重置思考缓存
     */
    public void resetReasoningBuffer() {
        reasoningBuffer.setLength(0);
        isInReasoning = false;
    }

    /**
     * 发送GET请求
     */
    public void get(final String urlStr, final ApiCallback<String> callback) {
        executorService.execute(new Runnable() {
                @Override
                public void run() {
                    HttpURLConnection connection = null;
                    try {
                        URL url = new URL(urlStr);
                        connection = (HttpURLConnection) url.openConnection();
                        connection.setRequestMethod("GET");
                        connection.setConnectTimeout(ApiConfig.CONNECT_TIMEOUT);
                        connection.setReadTimeout(ApiConfig.READ_TIMEOUT);

                        if (apiKey != null && !apiKey.isEmpty()) {
                            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                        }
                        connection.setRequestProperty("Content-Type", "application/json");

                        int responseCode = connection.getResponseCode();
                        if (responseCode == HttpURLConnection.HTTP_OK) {
                            String response = readStream(connection.getInputStream());
                            callback.onSuccess(response);
                        } else {
                            String error = readStream(connection.getErrorStream());
                            callback.onError("HTTP " + responseCode + ": " + error);
                        }
                    } catch (IOException e) {
                        callback.onError("网络异常，请检查连接");
                    } finally {
                        if (connection != null) {
                            connection.disconnect();
                        }
                    }
                }
            });
    }

    /**
     * 发送POST请求
     */
    public void post(final String urlStr, final String jsonBody, final ApiCallback<String> callback) {
        executorService.execute(new Runnable() {
                @Override
                public void run() {
                    HttpURLConnection connection = null;
                    try {
                        URL url = new URL(urlStr);
                        connection = (HttpURLConnection) url.openConnection();
                        connection.setRequestMethod("POST");
                        connection.setConnectTimeout(ApiConfig.CONNECT_TIMEOUT);
                        connection.setReadTimeout(ApiConfig.READ_TIMEOUT);
                        connection.setDoOutput(true);
                        connection.setDoInput(true);

                        if (apiKey != null && !apiKey.isEmpty()) {
                            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                        }
                        connection.setRequestProperty("Content-Type", "application/json");

                        OutputStream os = connection.getOutputStream();
                        os.write(jsonBody.getBytes("UTF-8"));
                        os.flush();
                        os.close();

                        int responseCode = connection.getResponseCode();
                        if (responseCode == HttpURLConnection.HTTP_OK) {
                            String response = readStream(connection.getInputStream());
                            callback.onSuccess(response);
                        } else {
                            String error = readStream(connection.getErrorStream());
                            callback.onError("HTTP " + responseCode + ": " + error);
                        }
                    } catch (IOException e) {
                        callback.onError("网络异常，请检查连接");
                    } finally {
                        if (connection != null) {
                            connection.disconnect();
                        }
                    }
                }
            });
    }

    /**
     * 流式聊天请求（修复版：支持DeepSeek R1思考内容完整输出）
     */
    public void streamChat(final String model, final List<Message> messages, final String systemPrompt, final StreamCallback callback) {
        resetReasoningBuffer();

        executorService.execute(new Runnable() {
                @Override
                public void run() {
                    HttpURLConnection connection = null;
                    BufferedReader reader = null;
                    try {
                        URL url = new URL(ApiConfig.BASE_URL + ApiConfig.CHAT_COMPLETIONS);
                        connection = (HttpURLConnection) url.openConnection();
                        connection.setRequestMethod("POST");
                        connection.setConnectTimeout(ApiConfig.CONNECT_TIMEOUT);
                        connection.setReadTimeout(ApiConfig.READ_TIMEOUT);
                        connection.setDoOutput(true);
                        connection.setDoInput(true);

                        if (apiKey != null && !apiKey.isEmpty()) {
                            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
                        }
                        connection.setRequestProperty("Content-Type", "application/json");
                        connection.setRequestProperty("Accept", "text/event-stream");

                        // 构建请求体
                        JSONObject requestBody = buildChatRequestBody(model, messages, systemPrompt);

                        OutputStream os = connection.getOutputStream();
                        os.write(requestBody.toString().getBytes("UTF-8"));
                        os.flush();
                        os.close();

                        int responseCode = connection.getResponseCode();
                        if (responseCode == HttpURLConnection.HTTP_OK) {
                            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                            String line;
                            while ((line = reader.readLine()) != null) {
                                if (line.startsWith("data: ")) {
                                    String data = line.substring(6);
                                    if ("[DONE]".equals(data)) {
                                        // 🔴 思考结束，闭合标签
                                        if (isInReasoning) {
                                            callback.onContent("\n</思考>\n\n");
                                            isInReasoning = false;
                                        }
                                        callback.onComplete();
                                        break;
                                    }

                                    String content = parseStreamContent(data);
                                    if (content != null && !content.isEmpty()) {
                                        callback.onContent(content);
                                    }
                                }
                            }
                        } else {
                            String error = readStream(connection.getErrorStream());
                            callback.onError("HTTP " + responseCode + ": " + error);
                        }
                    } catch (IOException e) {
                        callback.onError("网络异常，请检查连接");
                    } finally {
                        try {
                            if (reader != null) {
                                reader.close();
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        if (connection != null) {
                            connection.disconnect();
                        }
                    }
                }
            });
    }

    /**
     * 构建聊天请求体
     */
    private JSONObject buildChatRequestBody(String model, List<Message> messages, String systemPrompt) {
        JSONObject body = new JSONObject();
        try {
            body.put("model", model);
            body.put("stream", true);

            JSONArray messagesArray = new JSONArray();

            // 添加系统提示词
            if (systemPrompt != null && !systemPrompt.isEmpty()) {
                JSONObject systemMsg = new JSONObject();
                systemMsg.put("role", "system");
                systemMsg.put("content", systemPrompt);
                messagesArray.put(systemMsg);
            }

            // 添加历史消息
            for (int i = 0; i < messages.size(); i++) {
                Message msg = messages.get(i);
                JSONObject msgObj = new JSONObject();

                if (msg.getType() == Message.TYPE_USER) {
                    msgObj.put("role", "user");
                } else if (msg.getType() == Message.TYPE_AI) {
                    msgObj.put("role", "assistant");
                } else {
                    msgObj.put("role", "system");
                }

                msgObj.put("content", msg.getContent());
                messagesArray.put(msgObj);
            }

            body.put("messages", messagesArray);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return body;
    }

    /**
     * 修复版：解析流式内容（完美支持DeepSeek R1的reasoning_content，避免逐字输出）
     */
    private String parseStreamContent(String data) {
        try {
            JSONObject json = new JSONObject(data);
            JSONArray choices = json.optJSONArray("choices");
            if (choices != null && choices.length() > 0) {
                JSONObject choice = choices.optJSONObject(0);
                JSONObject delta = choice.optJSONObject("delta");
                if (delta != null) {
                    // 1. 优先处理思考内容（reasoning_content）
                    String reasoningContent = delta.optString("reasoning_content", null);
                    if (reasoningContent != null && !reasoningContent.isEmpty() && !"null".equals(reasoningContent)) {
                        // 累积思考内容
                        reasoningBuffer.append(reasoningContent);

                        // 首次输出思考时，添加<思考>开头标签
                        if (!isInReasoning) {
                            isInReasoning = true;
                            return "<思考>\n" + reasoningContent;
                        }
                        // 后续直接返回内容，不重复加标签
                        return reasoningContent;
                    }

                    // 2. 处理正式回复内容（content）
                    String content = delta.optString("content", null);
                    if (content != null && !content.isEmpty() && !"null".equals(content)) {
                        // 如果之前在输出思考，先闭合标签
                        if (isInReasoning) {
                            isInReasoning = false;
                            return "\n</思考>\n" + content;
                        }
                        return content;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    /**
     * 读取输入流
     */
    private String readStream(InputStream is) throws IOException {
        if (is == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        return sb.toString();
    }
}

