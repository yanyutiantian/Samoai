package com.samoai.ai.adapter;

import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.samoai.ai.model.ModelInfo;
import com.samoai.ai.utils.AnimUtils;
import com.samoai.ai.utils.UiUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 模型列表适配器
 */
public class ModelAdapter extends BaseAdapter {
    
    private android.content.Context context;
    private List<ModelInfo> models;
    private OnModelClickListener clickListener;
    private String selectedModelId;
    
    // 颜色
    private static final int COLOR_BG_NORMAL = Color.WHITE;
    private static final int COLOR_BG_SELECTED = Color.parseColor("#ECFDF5");
    private static final int COLOR_NAME = Color.parseColor("#111827");
    private static final int COLOR_ID = Color.parseColor("#6B7280");
    private static final int COLOR_SELECTED_TEXT = Color.parseColor("#10A37F");
    private static final int COLOR_DIVIDER = Color.parseColor("#E5E7EB");
    
    public interface OnModelClickListener {
        void onModelClick(ModelInfo model, int position);
    }
    
    public ModelAdapter(android.content.Context context) {
        this.context = context;
        this.models = new ArrayList<ModelInfo>();
    }
    
    public void setOnModelClickListener(OnModelClickListener listener) {
        this.clickListener = listener;
    }
    
    public void setModels(List<ModelInfo> models) {
        this.models = models != null ? models : new ArrayList<ModelInfo>();
        notifyDataSetChanged();
    }
    
    public void setSelectedModelId(String modelId) {
        this.selectedModelId = modelId;
        notifyDataSetChanged();
    }
    
    @Override
    public int getCount() {
        return models.size();
    }
    
    @Override
    public Object getItem(int position) {
        return models.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return position;
    }
    
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ModelViewHolder holder;
        
        if (convertView == null) {
            holder = new ModelViewHolder();
            holder.container = createItemContainer();
            holder.nameView = createNameView();
            holder.idView = createIdView();
            holder.divider = createDivider();
            
            holder.container.addView(holder.nameView);
            holder.container.addView(holder.idView);
            holder.container.addView(holder.divider);
            
            convertView = holder.container;
            convertView.setTag(holder);
        } else {
            holder = (ModelViewHolder) convertView.getTag();
        }
        
        final ModelInfo model = models.get(position);
        bindModel(holder, model);
        
        // 选中状态
        boolean isSelected = model.getId().equals(selectedModelId);
        holder.container.setBackgroundColor(isSelected ? COLOR_BG_SELECTED : COLOR_BG_NORMAL);
        holder.nameView.setTextColor(isSelected ? COLOR_SELECTED_TEXT : COLOR_NAME);
        
        // 点击事件
        holder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                if (clickListener != null) {
                    clickListener.onModelClick(model, position);
                }
            }
        });
        
        // 按压效果
        holder.container.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        AnimUtils.listItemPress(v, true);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        AnimUtils.listItemPress(v, false);
                        break;
                }
                return false;
            }
        });
        
        return convertView;
    }
    
    private LinearLayout createItemContainer() {
        LinearLayout container = new LinearLayout(context);
        container.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        container.setOrientation(LinearLayout.VERTICAL);
        int padding = UiUtils.dpToPx(context, 16);
        container.setPadding(padding, padding, padding, 0);
        return container;
    }
    
    private TextView createNameView() {
        TextView textView = new TextView(context);
        textView.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        textView.setTextSize(15);
        textView.setSingleLine(true);
        return textView;
    }
    
    private TextView createIdView() {
        TextView textView = new TextView(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.topMargin = UiUtils.dpToPx(context, 2);
        params.bottomMargin = UiUtils.dpToPx(context, 12);
        textView.setLayoutParams(params);
        textView.setTextSize(12);
        textView.setTextColor(COLOR_ID);
        textView.setSingleLine(true);
        return textView;
    }
    
    private View createDivider() {
        View divider = new View(context);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(context, 1)
        ));
        divider.setBackgroundColor(COLOR_DIVIDER);
        return divider;
    }
    
    private void bindModel(ModelViewHolder holder, ModelInfo model) {
        // 简化显示名称
        String name = model.getId();
        if (name.contains("/")) {
            name = name.substring(name.lastIndexOf("/") + 1);
        }
        holder.nameView.setText(name);
        holder.idView.setText(model.getId());
    }
    
    private static class ModelViewHolder {
        LinearLayout container;
        TextView nameView;
        TextView idView;
        View divider;
    }
}
