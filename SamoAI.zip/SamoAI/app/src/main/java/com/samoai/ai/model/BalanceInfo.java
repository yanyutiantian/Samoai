package com.samoai.ai.model;

import org.json.JSONObject;

/**
 * 余额信息实体类
 */
public class BalanceInfo {
    private double totalUsage;
    private double totalRemaining;
    private String currency;
    
    public BalanceInfo() {
        this.currency = "Money";
    }
    
    public double getTotalUsage() {
        return totalUsage;
    }
    
    public void setTotalUsage(double totalUsage) {
        this.totalUsage = totalUsage;
    }
    
    public double getTotalRemaining() {
        return totalRemaining;
    }
    
    public void setTotalRemaining(double totalRemaining) {
        this.totalRemaining = totalRemaining;
    }
    
    public String getCurrency() {
        return currency;
    }
    
    public void setCurrency(String currency) {
        this.currency = currency;
    }
    
    /**
     * 格式化显示余额
     */
    public String getFormattedUsage() {
        return String.format("%.4f %s", totalUsage, currency);
    }
    
    public static BalanceInfo fromJson(JSONObject json) {
        BalanceInfo info = new BalanceInfo();
        try {
            JSONObject data = json.optJSONObject("data");
            if (data != null) {
                info.setTotalUsage(data.optDouble("total_usage", 0));
                info.setTotalRemaining(data.optDouble("total_remaining", 0));
                info.setCurrency(data.optString("currency", "Money"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return info;
    }
}
