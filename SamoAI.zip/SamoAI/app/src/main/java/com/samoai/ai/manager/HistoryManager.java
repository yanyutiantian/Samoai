package com.samoai.ai.manager;

import com.samoai.ai.model.ChatHistory;
import com.samoai.ai.model.Message;
import com.samoai.ai.store.DataStore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 历史记录管理器
 */
public class HistoryManager {
    private static HistoryManager instance;
    private List<ChatHistory> histories;
    
    private HistoryManager() {
        loadHistories();
    }
    
    public static synchronized HistoryManager getInstance() {
        if (instance == null) {
            instance = new HistoryManager();
        }
        return instance;
    }
    
    /**
     * 加载历史记录
     */
    private void loadHistories() {
        histories = DataStore.getInstance().getHistories();
        if (histories == null) {
            histories = new ArrayList<ChatHistory>();
        }
        sortHistories();
    }
    
    /**
     * 按时间排序（最新的在前）
     */
    private void sortHistories() {
        Collections.sort(histories, new Comparator<ChatHistory>() {
            @Override
            public int compare(ChatHistory h1, ChatHistory h2) {
                return Long.compare(h2.getLastTime(), h1.getLastTime());
            }
        });
    }
    
    /**
     * 获取所有历史记录
     */
    public List<ChatHistory> getHistories() {
        return new ArrayList<ChatHistory>(histories);
    }
    
    /**
     * 添加历史记录
     */
    public void addHistory(ChatHistory history) {
        if (history != null) {
            histories.add(history);
            sortHistories();
            DataStore.getInstance().saveHistories(histories);
        }
    }
    
    /**
     * 更新历史记录
     */
    public void updateHistory(ChatHistory history) {
        if (history == null) return;
        
        for (int i = 0; i < histories.size(); i++) {
            if (histories.get(i).getId().equals(history.getId())) {
                histories.set(i, history);
                sortHistories();
                DataStore.getInstance().saveHistories(histories);
                break;
            }
        }
    }
    
    /**
     * 删除历史记录
     */
    public void deleteHistory(String historyId) {
        for (int i = 0; i < histories.size(); i++) {
            if (histories.get(i).getId().equals(historyId)) {
                histories.remove(i);
                DataStore.getInstance().saveHistories(histories);
                break;
            }
        }
    }
    
    /**
     * 清空所有历史记录
     */
    public void clearAllHistories() {
        histories.clear();
        DataStore.getInstance().clearAllHistories();
    }
    
    /**
     * 根据ID获取历史记录
     */
    public ChatHistory getHistoryById(String id) {
        for (int i = 0; i < histories.size(); i++) {
            if (histories.get(i).getId().equals(id)) {
                return histories.get(i);
            }
        }
        return null;
    }
    
    /**
     * 根据角色卡ID获取历史记录
     */
    public List<ChatHistory> getHistoriesByCharacter(String characterId) {
        List<ChatHistory> result = new ArrayList<ChatHistory>();
        for (int i = 0; i < histories.size(); i++) {
            if (histories.get(i).getCharacterId().equals(characterId)) {
                result.add(histories.get(i));
            }
        }
        return result;
    }
    
    /**
     * 归档当前对话为历史记录
     */
    public ChatHistory archiveCurrentChat(String characterId, String characterName, List<Message> messages) {
        if (messages == null || messages.isEmpty()) {
            return null;
        }
        
        ChatHistory history = new ChatHistory();
        history.setCharacterId(characterId);
        history.setCharacterName(characterName);
        history.setMessages(new ArrayList<Message>(messages));
        
        // 设置最后一条消息
        Message lastMsg = messages.get(messages.size() - 1);
        history.setLastMessage(lastMsg.getContent());
        history.setLastTime(lastMsg.getTimestamp());
        
        addHistory(history);
        return history;
    }
    
    /**
     * 获取历史记录数量
     */
    public int getHistoryCount() {
        return histories.size();
    }
    
    /**
     * 是否有历史记录
     */
    public boolean hasHistories() {
        return !histories.isEmpty();
    }
}
