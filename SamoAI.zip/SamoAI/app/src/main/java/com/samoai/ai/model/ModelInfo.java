package com.samoai.ai.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * AI模型信息实体类
 */
public class ModelInfo {
    private String id;
    private String object;
    private long created;
    private String ownedBy;
    
    public ModelInfo() {
    }
    
    public ModelInfo(String id, String ownedBy) {
        this.id = id;
        this.ownedBy = ownedBy;
        this.object = "model";
        this.created = System.currentTimeMillis() / 1000;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getObject() {
        return object;
    }
    
    public void setObject(String object) {
        this.object = object;
    }
    
    public long getCreated() {
        return created;
    }
    
    public void setCreated(long created) {
        this.created = created;
    }
    
    public String getOwnedBy() {
        return ownedBy;
    }
    
    public void setOwnedBy(String ownedBy) {
        this.ownedBy = ownedBy;
    }
    
    public static ModelInfo fromJson(JSONObject json) {
        ModelInfo model = new ModelInfo();
        try {
            model.setId(json.optString("id", ""));
            model.setObject(json.optString("object", "model"));
            model.setCreated(json.optLong("created", 0));
            model.setOwnedBy(json.optString("owned_by", ""));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;
    }
    
    @Override
    public String toString() {
        return id;
    }
}
