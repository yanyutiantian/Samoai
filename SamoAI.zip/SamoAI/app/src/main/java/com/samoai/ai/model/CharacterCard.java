package com.samoai.ai.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 角色卡实体类（支持SillyTavern V1和V2格式）
 */
public class CharacterCard {
    private String id;
    private String name;
    private String description;
    private String personality;
    private String scenario;
    private String firstMes;
    private String mesExample;
    private String creatorcomment;
    private String avatar;
    private List<String> alternateGreetings;
    private String systemPrompt;
    private String creator;
    private String characterVersion;
    private List<String> tags;
    private long createTime;
    private long updateTime;
    
    public CharacterCard() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.createTime = System.currentTimeMillis();
        this.updateTime = System.currentTimeMillis();
        this.alternateGreetings = new ArrayList<String>();
        this.tags = new ArrayList<String>();
    }
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getPersonality() { return personality; }
    public void setPersonality(String personality) { this.personality = personality; }
    
    public String getScenario() { return scenario; }
    public void setScenario(String scenario) { this.scenario = scenario; }
    
    public String getFirstMes() { return firstMes; }
    public void setFirstMes(String firstMes) { this.firstMes = firstMes; }
    
    public String getMesExample() { return mesExample; }
    public void setMesExample(String mesExample) { this.mesExample = mesExample; }
    
    public String getCreatorcomment() { return creatorcomment; }
    public void setCreatorcomment(String creatorcomment) { this.creatorcomment = creatorcomment; }
    
    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }
    
    public List<String> getAlternateGreetings() { return alternateGreetings; }
    public void setAlternateGreetings(List<String> alternateGreetings) { this.alternateGreetings = alternateGreetings; }
    
    public String getSystemPrompt() { return systemPrompt; }
    public void setSystemPrompt(String systemPrompt) { this.systemPrompt = systemPrompt; }
    
    public String getCreator() { return creator; }
    public void setCreator(String creator) { this.creator = creator; }
    
    public String getCharacterVersion() { return characterVersion; }
    public void setCharacterVersion(String characterVersion) { this.characterVersion = characterVersion; }
    
    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }
    
    public long getCreateTime() { return createTime; }
    public void setCreateTime(long createTime) { this.createTime = createTime; }
    
    public long getUpdateTime() { return updateTime; }
    public void setUpdateTime(long updateTime) { this.updateTime = updateTime; }
    
    /**
     * 构建系统提示词
     */
    public String buildSystemPrompt() {
        StringBuilder sb = new StringBuilder();
        if (systemPrompt != null && !systemPrompt.isEmpty()) {
            sb.append(systemPrompt);
        } else {
            sb.append("You are ").append(name != null ? name : "Assistant").append(".");
            if (description != null && !description.isEmpty()) {
                sb.append(" ").append(description);
            }
            if (personality != null && !personality.isEmpty()) {
                sb.append(" Personality: ").append(personality);
            }
            if (scenario != null && !scenario.isEmpty()) {
                sb.append(" Scenario: ").append(scenario);
            }
        }
        return sb.toString();
    }
    
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        try {
            json.put("id", id);
            json.put("name", name);
            json.put("description", description);
            json.put("personality", personality);
            json.put("scenario", scenario);
            json.put("first_mes", firstMes);
            json.put("mes_example", mesExample);
            json.put("creatorcomment", creatorcomment);
            json.put("avatar", avatar);
            json.put("system_prompt", systemPrompt);
            json.put("creator", creator);
            json.put("character_version", characterVersion);
            json.put("create_time", createTime);
            json.put("update_time", updateTime);
            
            if (alternateGreetings != null && !alternateGreetings.isEmpty()) {
                JSONArray arr = new JSONArray();
                for (int i = 0; i < alternateGreetings.size(); i++) {
                    arr.put(alternateGreetings.get(i));
                }
                json.put("alternate_greetings", arr);
            }
            
            if (tags != null && !tags.isEmpty()) {
                JSONArray arr = new JSONArray();
                for (int i = 0; i < tags.size(); i++) {
                    arr.put(tags.get(i));
                }
                json.put("tags", arr);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
    
    /**
     * 从SillyTavern JSON解析（支持V1和V2格式）
     */
    public static CharacterCard fromSillyTavernJson(JSONObject json) {
        CharacterCard card = new CharacterCard();
        try {
            // 检测V2格式 (chara_card_v2)
            if (json.has("spec") && json.has("data")) {
                JSONObject data = json.optJSONObject("data");
                if (data != null) {
                    parseV2Data(card, data);
                }
            } else {
                // V1格式直接解析
                parseV1Data(card, json);
            }
            card.setUpdateTime(System.currentTimeMillis());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return card;
    }
    
    /**
     * 解析V1格式数据
     */
    private static void parseV1Data(CharacterCard card, JSONObject json) {
        card.setName(json.optString("name", ""));
        card.setDescription(json.optString("description", ""));
        card.setPersonality(json.optString("personality", ""));
        card.setScenario(json.optString("scenario", ""));
        card.setFirstMes(json.optString("first_mes", ""));
        card.setMesExample(json.optString("mes_example", ""));
        card.setCreatorcomment(json.optString("creatorcomment", ""));
        card.setAvatar(json.optString("avatar", ""));
        card.setSystemPrompt(json.optString("system_prompt", ""));
        card.setCreator(json.optString("creator", ""));
        card.setCharacterVersion(json.optString("character_version", ""));
        
        // 解析备用问候语
        JSONArray altGreetings = json.optJSONArray("alternate_greetings");
        if (altGreetings != null) {
            List<String> greetings = new ArrayList<String>();
            for (int i = 0; i < altGreetings.length(); i++) {
                greetings.add(altGreetings.optString(i, ""));
            }
            card.setAlternateGreetings(greetings);
        }
        
        // 解析标签
        JSONArray tags = json.optJSONArray("tags");
        if (tags != null) {
            List<String> tagList = new ArrayList<String>();
            for (int i = 0; i < tags.length(); i++) {
                tagList.add(tags.optString(i, ""));
            }
            card.setTags(tagList);
        }
    }
    
    /**
     * 解析V2格式数据
     */
    private static void parseV2Data(CharacterCard card, JSONObject data) {
        card.setName(data.optString("name", ""));
        card.setDescription(data.optString("description", ""));
        card.setPersonality(data.optString("personality", ""));
        card.setScenario(data.optString("scenario", ""));
        card.setFirstMes(data.optString("first_mes", ""));
        card.setMesExample(data.optString("mes_example", ""));
        card.setCreatorcomment(data.optString("creator_notes", ""));
        card.setAvatar(data.optString("avatar", ""));
        card.setSystemPrompt(data.optString("system_prompt", ""));
        card.setCreator(data.optString("creator", ""));
        card.setCharacterVersion(data.optString("character_version", ""));
        
        // 解析备用问候语
        JSONArray altGreetings = data.optJSONArray("alternate_greetings");
        if (altGreetings != null) {
            List<String> greetings = new ArrayList<String>();
            for (int i = 0; i < altGreetings.length(); i++) {
                greetings.add(altGreetings.optString(i, ""));
            }
            card.setAlternateGreetings(greetings);
        }
        
        // 解析标签
        JSONArray tags = data.optJSONArray("tags");
        if (tags != null) {
            List<String> tagList = new ArrayList<String>();
            for (int i = 0; i < tags.length(); i++) {
                tagList.add(tags.optString(i, ""));
            }
            card.setTags(tagList);
        }
    }
    
    /**
     * 验证是否为有效的SillyTavern角色卡（支持V1和V2）
     */
    public static boolean isValidSillyTavernCard(JSONObject json) {
        if (json == null) return false;
        
        // V2格式检测
        if (json.has("spec") && json.has("data")) {
            String spec = json.optString("spec", "");
            if (spec.contains("chara_card")) {
                JSONObject data = json.optJSONObject("data");
                return data != null && data.has("name") && !data.optString("name", "").isEmpty();
            }
        }
        
        // V1格式检测
        return json.has("name") && !json.optString("name", "").isEmpty();
    }
}
