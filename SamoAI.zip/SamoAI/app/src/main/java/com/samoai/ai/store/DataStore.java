package com.samoai.ai.store;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.samoai.ai.model.CharacterCard;
import com.samoai.ai.model.ChatHistory;
import com.samoai.ai.model.Message;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据存储管理类
 */
public class DataStore {
    private static final String PREF_NAME = "samoai_prefs";
    private static final String KEY_API_KEY = "api_key";
    private static final String KEY_CURRENT_MODEL = "current_model";
    private static final String KEY_CHARACTERS = "characters";
    private static final String KEY_HISTORIES = "histories";
    private static final String KEY_CURRENT_CHARACTER = "current_character";
    private static final String KEY_CURRENT_MESSAGES = "current_messages";
    
    private static DataStore instance;
    private SharedPreferences prefs;
    private Context context;
    
    private DataStore() {
    }
    
    public static synchronized DataStore getInstance() {
        if (instance == null) {
            instance = new DataStore();
        }
        return instance;
    }
    
    public void init(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }
    
    // ========== API Key ==========
    
    public void saveApiKey(String apiKey) {
        prefs.edit().putString(KEY_API_KEY, apiKey).apply();
    }
    
    public String getApiKey() {
        return prefs.getString(KEY_API_KEY, "");
    }
    
    // ========== 当前模型 ==========
    
    public void saveCurrentModel(String model) {
        prefs.edit().putString(KEY_CURRENT_MODEL, model).apply();
    }
    
    public String getCurrentModel() {
        return prefs.getString(KEY_CURRENT_MODEL, "无");
    }
    
    // ========== 角色卡 ==========
    
    public void saveCharacters(List<CharacterCard> characters) {
        try {
            JSONArray array = new JSONArray();
            for (int i = 0; i < characters.size(); i++) {
                array.put(characters.get(i).toJson());
            }
            prefs.edit().putString(KEY_CHARACTERS, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<CharacterCard> getCharacters() {
        List<CharacterCard> list = new ArrayList<CharacterCard>();
        try {
            String json = prefs.getString(KEY_CHARACTERS, "[]");
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                list.add(CharacterCard.fromSillyTavernJson(array.optJSONObject(i)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public void addCharacter(CharacterCard character) {
        List<CharacterCard> list = getCharacters();
        list.add(character);
        saveCharacters(list);
    }
    
    public void updateCharacter(CharacterCard character) {
        List<CharacterCard> list = getCharacters();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(character.getId())) {
                list.set(i, character);
                break;
            }
        }
        saveCharacters(list);
    }
    
    public void deleteCharacter(String characterId) {
        List<CharacterCard> list = getCharacters();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(characterId)) {
                list.remove(i);
                break;
            }
        }
        saveCharacters(list);
    }
    
    // ========== 历史记录 ==========
    
    public void saveHistories(List<ChatHistory> histories) {
        try {
            JSONArray array = new JSONArray();
            for (int i = 0; i < histories.size(); i++) {
                array.put(histories.get(i).toJson());
            }
            prefs.edit().putString(KEY_HISTORIES, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<ChatHistory> getHistories() {
        List<ChatHistory> list = new ArrayList<ChatHistory>();
        try {
            String json = prefs.getString(KEY_HISTORIES, "[]");
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                list.add(ChatHistory.fromJson(array.optJSONObject(i)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public void addHistory(ChatHistory history) {
        List<ChatHistory> list = getHistories();
        list.add(history);
        saveHistories(list);
    }
    
    public void updateHistory(ChatHistory history) {
        List<ChatHistory> list = getHistories();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(history.getId())) {
                list.set(i, history);
                break;
            }
        }
        saveHistories(list);
    }
    
    public void deleteHistory(String historyId) {
        List<ChatHistory> list = getHistories();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(historyId)) {
                list.remove(i);
                break;
            }
        }
        saveHistories(list);
    }
    
    public void clearAllHistories() {
        prefs.edit().remove(KEY_HISTORIES).apply();
    }
    
    // ========== 当前对话 ==========
    
    public void saveCurrentCharacter(CharacterCard character) {
        if (character != null) {
            prefs.edit().putString(KEY_CURRENT_CHARACTER, character.toJson().toString()).apply();
        } else {
            prefs.edit().remove(KEY_CURRENT_CHARACTER).apply();
        }
    }
    
    public CharacterCard getCurrentCharacter() {
        try {
            String json = prefs.getString(KEY_CURRENT_CHARACTER, null);
            if (json != null) {
                return CharacterCard.fromSillyTavernJson(new JSONObject(json));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public void saveCurrentMessages(List<Message> messages) {
        try {
            JSONArray array = new JSONArray();
            for (int i = 0; i < messages.size(); i++) {
                array.put(messages.get(i).toJson());
            }
            prefs.edit().putString(KEY_CURRENT_MESSAGES, array.toString()).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<Message> getCurrentMessages() {
        List<Message> list = new ArrayList<Message>();
        try {
            String json = prefs.getString(KEY_CURRENT_MESSAGES, "[]");
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                list.add(Message.fromJson(array.optJSONObject(i)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    public void clearCurrentMessages() {
        prefs.edit().remove(KEY_CURRENT_MESSAGES).apply();
    }
    
    // ========== 导出/导入 ==========
    
    /**
     * 导出所有数据到文件
     */
    public boolean exportData(File exportFile) {
        try {
            JSONObject exportData = new JSONObject();
            exportData.put("api_key", getApiKey());
            exportData.put("current_model", getCurrentModel());
            exportData.put("characters", new JSONArray(prefs.getString(KEY_CHARACTERS, "[]")));
            exportData.put("histories", new JSONArray(prefs.getString(KEY_HISTORIES, "[]")));
            
            String currentChar = prefs.getString(KEY_CURRENT_CHARACTER, null);
            if (currentChar != null) {
                exportData.put("current_character", new JSONObject(currentChar));
            }
            
            FileOutputStream fos = new FileOutputStream(exportFile);
            fos.write(exportData.toString().getBytes("UTF-8"));
            fos.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 从文件导入数据
     */
    public boolean importData(File importFile) {
        try {
            FileInputStream fis = new FileInputStream(importFile);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();
            fis.close();
            
            JSONObject importData = new JSONObject(sb.toString());
            
            SharedPreferences.Editor editor = prefs.edit();
            
            if (importData.has("api_key")) {
                editor.putString(KEY_API_KEY, importData.optString("api_key", ""));
            }
            if (importData.has("current_model")) {
                editor.putString(KEY_CURRENT_MODEL, importData.optString("current_model", "无"));
            }
            if (importData.has("characters")) {
                editor.putString(KEY_CHARACTERS, importData.optJSONArray("characters").toString());
            }
            if (importData.has("histories")) {
                editor.putString(KEY_HISTORIES, importData.optJSONArray("histories").toString());
            }
            if (importData.has("current_character")) {
                editor.putString(KEY_CURRENT_CHARACTER, importData.optJSONObject("current_character").toString());
            }
            
            editor.apply();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
