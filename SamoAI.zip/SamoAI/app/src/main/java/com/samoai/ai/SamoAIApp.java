package com.samoai.ai;

import android.app.Application;

import com.samoai.ai.store.DataStore;

/**
 * 应用入口
 */
public class SamoAIApp extends Application {
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        // 初始化数据存储
        DataStore.getInstance().init(this);
    }
}
