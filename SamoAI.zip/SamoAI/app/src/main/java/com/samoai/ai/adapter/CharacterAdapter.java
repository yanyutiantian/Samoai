package com.samoai.ai.adapter;

import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.samoai.ai.model.CharacterCard;
import com.samoai.ai.utils.AnimUtils;
import com.samoai.ai.utils.UiUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 角色卡列表适配器
 */
public class CharacterAdapter extends BaseAdapter {
    
    private android.content.Context context;
    private List<CharacterCard> characters;
    private OnCharacterClickListener clickListener;
    private String selectedId;
    
    // 颜色
    private static final int COLOR_BG_NORMAL = Color.WHITE;
    private static final int COLOR_BG_SELECTED = Color.parseColor("#ECFDF5");
    private static final int COLOR_NAME = Color.parseColor("#111827");
    private static final int COLOR_DESC = Color.parseColor("#6B7280");
    private static final int COLOR_SELECTED_BORDER = Color.parseColor("#10A37F");
    private static final int COLOR_DIVIDER = Color.parseColor("#E5E7EB");
    
    public interface OnCharacterClickListener {
        void onCharacterClick(CharacterCard character, int position);
    }
    
    public CharacterAdapter(android.content.Context context) {
        this.context = context;
        this.characters = new ArrayList<CharacterCard>();
    }
    
    public void setOnCharacterClickListener(OnCharacterClickListener listener) {
        this.clickListener = listener;
    }
    
    public void setCharacters(List<CharacterCard> characters) {
        this.characters = characters != null ? characters : new ArrayList<CharacterCard>();
        notifyDataSetChanged();
    }
    
    public void setSelectedId(String selectedId) {
        this.selectedId = selectedId;
        notifyDataSetChanged();
    }
    
    @Override
    public int getCount() {
        return characters.size();
    }
    
    @Override
    public Object getItem(int position) {
        return characters.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return position;
    }
    
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        CharacterViewHolder holder;
        
        if (convertView == null) {
            holder = new CharacterViewHolder();
            holder.container = createItemContainer();
            holder.nameView = createNameView();
            holder.descView = createDescView();
            holder.divider = createDivider();
            
            holder.container.addView(holder.nameView);
            holder.container.addView(holder.descView);
            holder.container.addView(holder.divider);
            
            convertView = holder.container;
            convertView.setTag(holder);
        } else {
            holder = (CharacterViewHolder) convertView.getTag();
        }
        
        final CharacterCard character = characters.get(position);
        bindCharacter(holder, character);
        
        // 选中状态
        boolean isSelected = character.getId().equals(selectedId);
        holder.container.setBackgroundColor(isSelected ? COLOR_BG_SELECTED : COLOR_BG_NORMAL);
        
        // 点击事件
        holder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                if (clickListener != null) {
                    clickListener.onCharacterClick(character, position);
                }
            }
        });
        
        // 按压效果
        holder.container.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        AnimUtils.listItemPress(v, true);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        AnimUtils.listItemPress(v, false);
                        break;
                }
                return false;
            }
        });
        
        return convertView;
    }
    
    private LinearLayout createItemContainer() {
        LinearLayout container = new LinearLayout(context);
        container.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        container.setOrientation(LinearLayout.VERTICAL);
        int padding = UiUtils.dpToPx(context, 16);
        container.setPadding(padding, padding, padding, 0);
        return container;
    }
    
    private TextView createNameView() {
        TextView textView = new TextView(context);
        textView.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        textView.setTextSize(16);
        textView.setTextColor(COLOR_NAME);
        textView.setSingleLine(true);
        return textView;
    }
    
    private TextView createDescView() {
        TextView textView = new TextView(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.topMargin = UiUtils.dpToPx(context, 4);
        params.bottomMargin = UiUtils.dpToPx(context, 12);
        textView.setLayoutParams(params);
        textView.setTextSize(13);
        textView.setTextColor(COLOR_DESC);
        textView.setMaxLines(2);
        textView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return textView;
    }
    
    private View createDivider() {
        View divider = new View(context);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(context, 1)
        ));
        divider.setBackgroundColor(COLOR_DIVIDER);
        return divider;
    }
    
    private void bindCharacter(CharacterViewHolder holder, CharacterCard character) {
        holder.nameView.setText(character.getName() != null ? 
            character.getName() : "未命名角色");
        
        String desc = character.getDescription();
        if (desc == null || desc.isEmpty()) {
            desc = character.getPersonality();
        }
        holder.descView.setText(desc != null && !desc.isEmpty() ? 
            desc : "暂无描述");
    }
    
    private static class CharacterViewHolder {
        LinearLayout container;
        TextView nameView;
        TextView descView;
        View divider;
    }
}
