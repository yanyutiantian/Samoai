package com.samoai.ai.utils;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;

/**
 * 动画工具类
 */
public class AnimUtils {
    
    public static final long DURATION_SHORT = 150;
    public static final long DURATION_NORMAL = 250;
    public static final long DURATION_LONG = 350;
    
    /**
     * 按钮点击缩放动画
     */
    public static void buttonClick(View view) {
        if (view == null) return;
        
        ScaleAnimation scaleDown = new ScaleAnimation(
            1.0f, 0.92f, 1.0f, 0.92f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        );
        scaleDown.setDuration(80);
        scaleDown.setFillAfter(true);
        
        ScaleAnimation scaleUp = new ScaleAnimation(
            0.92f, 1.0f, 0.92f, 1.0f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        );
        scaleUp.setDuration(80);
        scaleUp.setStartOffset(80);
        scaleUp.setFillAfter(true);
        
        AnimationSet set = new AnimationSet(false);
        set.addAnimation(scaleDown);
        set.addAnimation(scaleUp);
        view.startAnimation(set);
    }
    
    /**
     * 消息出现动画 - 从下往上淡入+缩放
     
    public static void messageAppear(View view) {
        if (view == null) return;
        
        view.setAlpha(0f);
        view.setTranslationY(50f);
        view.setScaleX(0.95f);
        view.setScaleY(0.95f);
        
        view.animate()
            .alpha(1f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(300)
            .setInterpolator(new DecelerateInterpolator())
            .start();
    }
    */
    /**
     * 页面淡入动画
     */
    public static void fadeIn(View view) {
        if (view == null) return;
        
        view.setAlpha(0f);
        view.animate()
            .alpha(1f)
            .setDuration(DURATION_NORMAL)
            .setInterpolator(new DecelerateInterpolator())
            .start();
    }
    
    /**
     * 页面淡出动画
     */
    public static void fadeOut(View view) {
        if (view == null) return;
        
        view.animate()
            .alpha(0f)
            .setDuration(DURATION_NORMAL)
            .setInterpolator(new DecelerateInterpolator())
            .start();
    }
    
    /**
     * Tab切换动画 - 淡入淡出+横向位移
     */
    public static void tabSwitch(View fromView, View toView, boolean toRight) {
        if (fromView != null) {
            fromView.animate()
                .alpha(0f)
                .translationX(toRight ? -100f : 100f)
                .setDuration(DURATION_NORMAL)
                .setInterpolator(new DecelerateInterpolator())
                .start();
        }
        
        if (toView != null) {
            toView.setAlpha(0f);
            toView.setTranslationX(toRight ? 100f : -100f);
            toView.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(DURATION_NORMAL)
                .setInterpolator(new DecelerateInterpolator())
                .start();
        }
    }
    
    /**
     * 底部滑入动画（弹窗）
     */
    public static void slideUp(View view) {
        if (view == null) return;
        
        view.setTranslationY(view.getHeight());
        view.setAlpha(0f);
        view.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(DURATION_NORMAL)
            .setInterpolator(new DecelerateInterpolator())
            .start();
    }
    
    /**
     * 底部滑出动画（弹窗关闭）
     */
    public static void slideDown(View view, final Runnable onEnd) {
        if (view == null) return;
        
        view.animate()
            .translationY(view.getHeight())
            .alpha(0f)
            .setDuration(DURATION_NORMAL)
            .setInterpolator(new DecelerateInterpolator())
            .setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    if (onEnd != null) {
                        onEnd.run();
                    }
                }
            })
            .start();
    }
    
    /**
     * 列表项按压动画
     */
    public static void listItemPress(View view, boolean pressed) {
        if (view == null) return;
        
        view.animate()
            .scaleX(pressed ? 0.98f : 1f)
            .scaleY(pressed ? 0.98f : 1f)
            .alpha(pressed ? 0.8f : 1f)
            .setDuration(100)
            .start();
    }
    
    /**
     * 脉冲动画（用于正在输入指示器）
     */
    public static ObjectAnimator createPulseAnimation(View view) {
        ObjectAnimator animator = ObjectAnimator.ofFloat(view, "alpha", 0.4f, 1f, 0.4f);
        animator.setDuration(1200);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        return animator;
    }
    
    /**
     * 打字机效果动画
     */
    public static void typewriterEffect(final android.widget.TextView textView, final String fullText, final long delayMillis, final Runnable onComplete) {
        if (textView == null || fullText == null) return;
        
        textView.setText("");
        final int length = fullText.length();
        
        final android.os.Handler handler = new android.os.Handler();
        final Runnable runnable = new Runnable() {
            private int index = 0;
            
            @Override
            public void run() {
                if (index < length) {
                    textView.append(String.valueOf(fullText.charAt(index)));
                    index++;
                    handler.postDelayed(this, delayMillis);
                } else {
                    if (onComplete != null) {
                        onComplete.run();
                    }
                }
            }
        };
        
        handler.postDelayed(runnable, delayMillis);
    }
}
