package com.samoai.ai.adapter;

import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.samoai.ai.model.ChatHistory;
import com.samoai.ai.utils.AnimUtils;
import com.samoai.ai.utils.UiUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 历史记录列表适配器
 */
public class HistoryAdapter extends BaseAdapter {
    
    private android.content.Context context;
    private List<ChatHistory> histories;
    private OnHistoryClickListener clickListener;
    private OnHistoryDeleteListener deleteListener;
    
    // 颜色
    private static final int COLOR_BG_NORMAL = Color.WHITE;
    private static final int COLOR_BG_PRESSED = Color.parseColor("#F3F4F6");
    private static final int COLOR_TITLE = Color.parseColor("#111827");
    private static final int COLOR_CONTENT = Color.parseColor("#6B7280");
    private static final int COLOR_TIME = Color.parseColor("#9CA3AF");
    private static final int COLOR_DIVIDER = Color.parseColor("#E5E7EB");
    
    public interface OnHistoryClickListener {
        void onHistoryClick(ChatHistory history, int position);
    }
    
    public interface OnHistoryDeleteListener {
        void onHistoryDelete(ChatHistory history, int position);
    }
    
    public HistoryAdapter(android.content.Context context) {
        this.context = context;
        this.histories = new ArrayList<ChatHistory>();
    }
    
    public void setOnHistoryClickListener(OnHistoryClickListener listener) {
        this.clickListener = listener;
    }
    
    public void setOnHistoryDeleteListener(OnHistoryDeleteListener listener) {
        this.deleteListener = listener;
    }
    
    public void setHistories(List<ChatHistory> histories) {
        this.histories = histories != null ? histories : new ArrayList<ChatHistory>();
        notifyDataSetChanged();
    }
    
    public void removeItem(int position) {
        if (position >= 0 && position < histories.size()) {
            histories.remove(position);
            notifyDataSetChanged();
        }
    }
    
    public void clear() {
        histories.clear();
        notifyDataSetChanged();
    }
    
    @Override
    public int getCount() {
        return histories.size();
    }
    
    @Override
    public Object getItem(int position) {
        return histories.get(position);
    }
    
    @Override
    public long getItemId(int position) {
        return position;
    }
    
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        HistoryViewHolder holder;
        
        if (convertView == null) {
            holder = new HistoryViewHolder();
            holder.container = createItemContainer();
            holder.titleView = createTitleView();
            holder.contentView = createContentView();
            holder.timeView = createTimeView();
            holder.divider = createDivider();
            
            holder.container.addView(holder.titleView);
            holder.container.addView(holder.contentView);
            holder.container.addView(holder.timeView);
            holder.container.addView(holder.divider);
            
            convertView = holder.container;
            convertView.setTag(holder);
        } else {
            holder = (HistoryViewHolder) convertView.getTag();
        }
        
        final ChatHistory history = histories.get(position);
        bindHistory(holder, history);
        
        // 点击事件
        holder.container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                if (clickListener != null) {
                    clickListener.onHistoryClick(history, position);
                }
            }
        });
        
        // 长按删除
        holder.container.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (deleteListener != null) {
                    deleteListener.onHistoryDelete(history, position);
                    return true;
                }
                return false;
            }
        });
        
        // 按压效果
        holder.container.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        AnimUtils.listItemPress(v, true);
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        AnimUtils.listItemPress(v, false);
                        break;
                }
                return false;
            }
        });
        
        return convertView;
    }
    
    private LinearLayout createItemContainer() {
        LinearLayout container = new LinearLayout(context);
        container.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(COLOR_BG_NORMAL);
        int padding = UiUtils.dpToPx(context, 16);
        container.setPadding(padding, padding, padding, 0);
        return container;
    }
    
    private TextView createTitleView() {
        TextView textView = new TextView(context);
        textView.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        textView.setTextSize(16);
        textView.setTextColor(COLOR_TITLE);
        textView.setSingleLine(true);
        return textView;
    }
    
    private TextView createContentView() {
        TextView textView = new TextView(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.topMargin = UiUtils.dpToPx(context, 4);
        textView.setLayoutParams(params);
        textView.setTextSize(14);
        textView.setTextColor(COLOR_CONTENT);
        textView.setMaxLines(2);
        textView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        return textView;
    }
    
    private TextView createTimeView() {
        TextView textView = new TextView(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.topMargin = UiUtils.dpToPx(context, 6);
        params.bottomMargin = UiUtils.dpToPx(context, 12);
        textView.setLayoutParams(params);
        textView.setTextSize(12);
        textView.setTextColor(COLOR_TIME);
        return textView;
    }
    
    private View createDivider() {
        View divider = new View(context);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(context, 1)
        ));
        divider.setBackgroundColor(COLOR_DIVIDER);
        return divider;
    }
    
    private void bindHistory(HistoryViewHolder holder, ChatHistory history) {
        holder.titleView.setText(history.getCharacterName() != null ? 
            history.getCharacterName() : "未知角色");
        
        String lastMsg = history.getLastMessage();
        holder.contentView.setText(lastMsg != null && !lastMsg.isEmpty() ? 
            lastMsg : "无消息");
        
        holder.timeView.setText(UiUtils.formatTime(history.getLastTime()));
    }
    
    private static class HistoryViewHolder {
        LinearLayout container;
        TextView titleView;
        TextView contentView;
        TextView timeView;
        View divider;
    }
}
