package com.samoai.ai.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.samoai.ai.adapter.ModelAdapter;
import com.samoai.ai.api.ApiCallback;
import com.samoai.ai.api.ApiConfig;
import com.samoai.ai.api.HttpClient;
import com.samoai.ai.model.BalanceInfo;
import com.samoai.ai.model.ModelInfo;
import com.samoai.ai.store.DataStore;
import com.samoai.ai.utils.AnimUtils;
import com.samoai.ai.utils.FileUtils;
import com.samoai.ai.utils.UiUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 我的页面
 */
public class ProfilePage extends ScrollView {
    
    private Activity activity;
    private Handler mainHandler;
    
    // UI组件
    private LinearLayout contentLayout;
    private LinearLayout headerLayout;
    private TextView titleView;
    
    // API Key区域
    private LinearLayout apiKeySection;
    private TextView apiKeyLabel;
    private TextView apiKeyValue;
    private Button changeKeyBtn;
    
    // 模型区域
    private LinearLayout modelSection;
    private TextView modelLabel;
    private TextView modelValue;
    private Button selectModelBtn;
    
    // 余额区域
    private LinearLayout balanceSection;
    private TextView balanceLabel;
    private TextView balanceValue;
    private Button refreshBalanceBtn;
    
    // 数据管理区域
    private LinearLayout dataSection;
    private TextView dataLabel;
    private Button exportBtn;
    private Button importBtn;
    
    // 版本号
    private TextView versionView;
    
    // 数据
    private List<ModelInfo> modelList;
    private String currentModel;
    
    // 颜色
    private static final int COLOR_PRIMARY = Color.parseColor("#10A37F");
    private static final int COLOR_BG = Color.parseColor("#F9FAFB");
    private static final int COLOR_CARD_BG = Color.WHITE;
    private static final int COLOR_TEXT_PRIMARY = Color.parseColor("#111827");
    private static final int COLOR_TEXT_SECONDARY = Color.parseColor("#6B7280");
    private static final int COLOR_LABEL = Color.parseColor("#374151");
    private static final int COLOR_BORDER = Color.parseColor("#E5E7EB");
    
    private static final int REQUEST_CODE_IMPORT = 2001;
    
    public ProfilePage(Activity activity) {
        super(activity);
        this.activity = activity;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.modelList = new ArrayList<ModelInfo>();
        init();
    }
    
    private void init() {
        setLayoutParams(new LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT
        ));
        setBackgroundColor(COLOR_BG);
        
        contentLayout = new LinearLayout(getContext());
        contentLayout.setLayoutParams(new LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.WRAP_CONTENT
        ));
        contentLayout.setOrientation(LinearLayout.VERTICAL);
        
        createHeader();
        createApiKeySection();
        createModelSection();
        createBalanceSection();
        createDataSection();
        createVersionView();
        
        addView(contentLayout);
        
        // 加载数据
        loadData();
    }
    
    /**
     * 创建顶部导航栏
     */
    private void createHeader() {
        headerLayout = new LinearLayout(getContext());
        headerLayout.setLayoutParams(new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 56)
        ));
        headerLayout.setOrientation(LinearLayout.HORIZONTAL);
        headerLayout.setGravity(Gravity.CENTER);
        headerLayout.setBackgroundColor(COLOR_CARD_BG);
        headerLayout.setPadding(
            UiUtils.dpToPx(getContext(), 16),
            0,
            UiUtils.dpToPx(getContext(), 16),
            0
        );
        
        titleView = new TextView(getContext());
        titleView.setText("我的");
        titleView.setTextSize(18);
        titleView.setTextColor(COLOR_TEXT_PRIMARY);
        
        headerLayout.addView(titleView);
        contentLayout.addView(headerLayout);
        
        // 添加分割线
        View divider = new View(getContext());
        divider.setLayoutParams(new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 1)
        ));
        divider.setBackgroundColor(COLOR_BORDER);
        contentLayout.addView(divider);
    }
    
    /**
     * 创建API Key区域
     */
    private void createApiKeySection() {
        apiKeySection = createSection();
        
        apiKeyLabel = createLabel("API Key");
        apiKeyValue = createValueText("未设置");
        apiKeyValue.setSingleLine(true);
        
        changeKeyBtn = createActionButton("修改Key");
        changeKeyBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                showChangeKeyDialog();
            }
        });
        
        apiKeySection.addView(apiKeyLabel);
        apiKeySection.addView(apiKeyValue);
        apiKeySection.addView(changeKeyBtn);
        
        contentLayout.addView(apiKeySection);
        contentLayout.addView(createSectionSpacing());
    }
    
    /**
     * 创建模型区域
     */
    private void createModelSection() {
        modelSection = createSection();
        
        modelLabel = createLabel("当前模型");
        modelValue = createValueText("加载中...");
        
        selectModelBtn = createActionButton("模型列表");
        selectModelBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                showModelSelectDialog();
            }
        });
        
        modelSection.addView(modelLabel);
        modelSection.addView(modelValue);
        modelSection.addView(selectModelBtn);
        
        contentLayout.addView(modelSection);
        contentLayout.addView(createSectionSpacing());
    }
    
    /**
     * 创建余额区域
     */
    private void createBalanceSection() {
        balanceSection = createSection();
        
        balanceLabel = createLabel("账户余额");
        balanceValue = createValueText("获取失败");
        
        refreshBalanceBtn = createActionButton("刷新余额");
        refreshBalanceBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                loadBalance();
            }
        });
        
        balanceSection.addView(balanceLabel);
        balanceSection.addView(balanceValue);
        balanceSection.addView(refreshBalanceBtn);
        
        contentLayout.addView(balanceSection);
        contentLayout.addView(createSectionSpacing());
    }
    
    /**
     * 创建数据管理区域
     */
    private void createDataSection() {
        dataSection = createSection();
        
        dataLabel = createLabel("数据管理");
        
        exportBtn = createActionButton("导出全部数据");
        exportBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                exportData();
            }
        });
        
        importBtn = createActionButton("导入数据");
        importBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                importData();
            }
        });
        
        dataSection.addView(dataLabel);
        dataSection.addView(exportBtn);
        dataSection.addView(importBtn);
        
        contentLayout.addView(dataSection);
        contentLayout.addView(createSectionSpacing());
    }
    
    /**
     * 创建版本号视图
     */
    private void createVersionView() {
        versionView = new TextView(getContext());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.WRAP_CONTENT
        );
        params.topMargin = UiUtils.dpToPx(getContext(), 32);
        params.bottomMargin = UiUtils.dpToPx(getContext(), 24);
        versionView.setLayoutParams(params);
        versionView.setText("v1.0.0");
        versionView.setTextSize(12);
        versionView.setTextColor(COLOR_TEXT_SECONDARY);
        versionView.setGravity(Gravity.CENTER);
        
        contentLayout.addView(versionView);
    }
    
    /**
     * 创建区域卡片
     */
    private LinearLayout createSection() {
        LinearLayout section = new LinearLayout(getContext());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.WRAP_CONTENT
        );
        params.leftMargin = UiUtils.dpToPx(getContext(), 16);
        params.rightMargin = UiUtils.dpToPx(getContext(), 16);
        section.setLayoutParams(params);
        section.setOrientation(LinearLayout.VERTICAL);
        section.setBackgroundColor(COLOR_CARD_BG);
        section.setPadding(
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16)
        );
        section.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
            COLOR_CARD_BG, 12, getContext()));
        return section;
    }
    
    /**
     * 创建区域间距
     */
    private View createSectionSpacing() {
        View spacing = new View(getContext());
        spacing.setLayoutParams(new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 12)
        ));
        return spacing;
    }
    
    /**
     * 创建标签
     */
    private TextView createLabel(String text) {
        TextView label = new TextView(getContext());
        label.setLayoutParams(new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.WRAP_CONTENT
        ));
        label.setText(text);
        label.setTextSize(14);
        label.setTextColor(COLOR_LABEL);
        return label;
    }
    
    /**
     * 创建值文本
     */
    private TextView createValueText(String text) {
        TextView value = new TextView(getContext());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.WRAP_CONTENT
        );
        params.topMargin = UiUtils.dpToPx(getContext(), 8);
        params.bottomMargin = UiUtils.dpToPx(getContext(), 12);
        value.setLayoutParams(params);
        value.setText(text);
        value.setTextSize(15);
        value.setTextColor(COLOR_TEXT_PRIMARY);
        return value;
    }
    
    /**
     * 创建操作按钮
     */
    private Button createActionButton(String text) {
        Button btn = new Button(getContext());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 44)
        );
        btn.setLayoutParams(params);
        btn.setText(text);
        btn.setTextSize(14);
        btn.setTextColor(COLOR_PRIMARY);
        btn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
            Color.parseColor("#ECFDF5"), 8, getContext()));
        btn.setAllCaps(false);
        return btn;
    }
    
    /**
     * 加载数据
     */
    private void loadData() {
        // API Key
        String apiKey = DataStore.getInstance().getApiKey();
        updateApiKeyDisplay(apiKey);
        
        // 当前模型
        currentModel = DataStore.getInstance().getCurrentModel();
        modelValue.setText(currentModel);
        
        // 加载余额
        loadBalance();
    }
    
    /**
     * 更新API Key显示
     */
    private void updateApiKeyDisplay(String apiKey) {
        if (apiKey == null || apiKey.isEmpty()) {
            apiKeyValue.setText("未设置");
        } else {
            // 中间打码显示
            String masked = maskApiKey(apiKey);
            apiKeyValue.setText(masked);
        }
    }
    
    /**
     * API Key打码
     */
    private String maskApiKey(String apiKey) {
        if (apiKey.length() <= 8) {
            return "****";
        }
        return apiKey.substring(0, 4) + "****" + apiKey.substring(apiKey.length() - 4);
    }
    
    /**
     * 显示修改Key对话框（美化版）
     */
    private void showChangeKeyDialog() {
        final android.app.Dialog dialog = new android.app.Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);
        
        FrameLayout container = new FrameLayout(getContext());
        container.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        container.setBackgroundColor(Color.parseColor("#80000000"));
        
        LinearLayout content = new LinearLayout(getContext());
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        contentParams.gravity = Gravity.CENTER;
        contentParams.leftMargin = UiUtils.dpToPx(getContext(), 32);
        contentParams.rightMargin = UiUtils.dpToPx(getContext(), 32);
        content.setLayoutParams(contentParams);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundDrawable(UiUtils.createRoundRectDrawable(Color.WHITE, 16, getContext()));
        content.setPadding(
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 24)
        );
        
        // 标题
        TextView titleView = new TextView(getContext());
        titleView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        titleView.setText("修改API Key");
        titleView.setTextSize(18);
        titleView.setTextColor(COLOR_TEXT_PRIMARY);
        titleView.setGravity(Gravity.CENTER);
        content.addView(titleView);
        
        // 输入框
        final EditText input = new EditText(getContext());
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 48)
        );
        inputParams.topMargin = UiUtils.dpToPx(getContext(), 16);
        input.setLayoutParams(inputParams);
        input.setHint("请输入API Key");
        input.setText(DataStore.getInstance().getApiKey());
        input.setTextSize(14);
        input.setTextColor(COLOR_TEXT_PRIMARY);
        input.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
            Color.parseColor("#F9FAFB"), 8, getContext()));
        input.setPadding(
            UiUtils.dpToPx(getContext(), 16),
            0,
            UiUtils.dpToPx(getContext(), 16),
            0
        );
        content.addView(input);
        
        // 按钮区域
        LinearLayout btnLayout = new LinearLayout(getContext());
        LinearLayout.LayoutParams btnLayoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        btnLayoutParams.topMargin = UiUtils.dpToPx(getContext(), 20);
        btnLayout.setLayoutParams(btnLayoutParams);
        btnLayout.setOrientation(LinearLayout.HORIZONTAL);
        
        // 取消按钮
        Button cancelBtn = new Button(getContext());
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
            0,
            UiUtils.dpToPx(getContext(), 44),
            1
        );
        cancelParams.rightMargin = UiUtils.dpToPx(getContext(), 8);
        cancelBtn.setLayoutParams(cancelParams);
        cancelBtn.setText("取消");
        cancelBtn.setTextSize(14);
        cancelBtn.setTextColor(COLOR_TEXT_SECONDARY);
        cancelBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
            Color.parseColor("#F3F4F6"), 12, getContext()));
        cancelBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnLayout.addView(cancelBtn);
        
        // 保存按钮
        Button saveBtn = new Button(getContext());
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(
            0,
            UiUtils.dpToPx(getContext(), 44),
            1
        );
        saveParams.leftMargin = UiUtils.dpToPx(getContext(), 8);
        saveBtn.setLayoutParams(saveParams);
        saveBtn.setText("保存");
        saveBtn.setTextSize(14);
        saveBtn.setTextColor(Color.WHITE);
        saveBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(COLOR_PRIMARY, 12, getContext()));
        saveBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String key = input.getText().toString().trim();
                DataStore.getInstance().saveApiKey(key);
                HttpClient.getInstance().setApiKey(key);
                updateApiKeyDisplay(key);
                UiUtils.showToast(getContext(), "已保存");
                dialog.dismiss();
            }
        });
        btnLayout.addView(saveBtn);
        
        content.addView(btnLayout);
        
        container.addView(content);
        dialog.setContentView(container);
        
        container.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        
        content.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // 阻止事件传递
            }
        });
        
        // 显示动画
        content.setScaleX(0.8f);
        content.setScaleY(0.8f);
        content.setAlpha(0f);
        dialog.show();
        content.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(200)
            .setInterpolator(new android.view.animation.DecelerateInterpolator())
            .start();
    }
    
    /**
     * 显示模型选择对话框（美化版）
     */
    private void showModelSelectDialog() {
        final android.app.Dialog dialog = new android.app.Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);
        
        FrameLayout container = new FrameLayout(getContext());
        container.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        container.setBackgroundColor(Color.parseColor("#80000000"));
        
        LinearLayout content = new LinearLayout(getContext());
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        contentParams.gravity = Gravity.BOTTOM;
        contentParams.leftMargin = UiUtils.dpToPx(getContext(), 16);
        contentParams.rightMargin = UiUtils.dpToPx(getContext(), 16);
        contentParams.bottomMargin = UiUtils.dpToPx(getContext(), 16);
        content.setLayoutParams(contentParams);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundDrawable(UiUtils.createRoundRectDrawable(Color.WHITE, 16, getContext()));
        content.setPadding(
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16)
        );
        
        // 标题
        TextView titleView = new TextView(getContext());
        titleView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        titleView.setText("选择模型");
        titleView.setTextSize(18);
        titleView.setTextColor(COLOR_TEXT_PRIMARY);
        titleView.setGravity(Gravity.CENTER);
        titleView.setPadding(0, 0, 0, UiUtils.dpToPx(getContext(), 16));
        content.addView(titleView);
        
        // 创建列表
        final ListView listView = new ListView(getContext());
        listView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 350)
        ));
        listView.setDivider(null);
        listView.setDividerHeight(0);
        
        final ModelAdapter adapter = new ModelAdapter(getContext());
        adapter.setModels(modelList);
        adapter.setSelectedModelId(currentModel);
        
        adapter.setOnModelClickListener(new ModelAdapter.OnModelClickListener() {
            @Override
            public void onModelClick(ModelInfo model, int position) {
                currentModel = model.getId();
                DataStore.getInstance().saveCurrentModel(currentModel);
                modelValue.setText(currentModel);
                dialog.dismiss();
                UiUtils.showToast(getContext(), "已选择：" + currentModel);
            }
        });
        
        listView.setAdapter(adapter);
        content.addView(listView);
        
        // 取消按钮
        Button cancelBtn = new Button(getContext());
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 48)
        );
        cancelParams.topMargin = UiUtils.dpToPx(getContext(), 16);
        cancelBtn.setLayoutParams(cancelParams);
        cancelBtn.setText("取消");
        cancelBtn.setTextSize(16);
        cancelBtn.setTextColor(COLOR_TEXT_SECONDARY);
        cancelBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
            Color.parseColor("#F3F4F6"), 12, getContext()));
        cancelBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        content.addView(cancelBtn);
        
        container.addView(content);
        dialog.setContentView(container);
        
        // 点击背景关闭
        container.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        
        content.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // 阻止事件传递
            }
        });
        
        // 加载模型列表
        loadModels(adapter);
        
        // 显示动画
        content.setTranslationY(UiUtils.dpToPx(getContext(), 400));
        content.setAlpha(0f);
        dialog.show();
        content.animate()
            .translationY(0)
            .alpha(1f)
            .setDuration(250)
            .setInterpolator(new android.view.animation.DecelerateInterpolator())
            .start();
    }
    
    /**
     * 加载模型列表
     */
    private void loadModels(final ModelAdapter adapter) {
        String apiKey = DataStore.getInstance().getApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            UiUtils.showToast(getContext(), "请先设置API Key");
            return;
        }
        
        HttpClient.getInstance().setApiKey(apiKey);
        HttpClient.getInstance().get(ApiConfig.BASE_URL + ApiConfig.MODELS, new ApiCallback<String>() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    JSONArray data = json.optJSONArray("data");
                    if (data != null) {
                        modelList.clear();
                        for (int i = 0; i < data.length(); i++) {
                            modelList.add(ModelInfo.fromJson(data.optJSONObject(i)));
                        }
                        
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                adapter.setModels(modelList);
                            }
                        });
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            
            @Override
            public void onError(String error) {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        UiUtils.showToast(getContext(), "获取模型列表失败");
                    }
                });
            }
        });
    }
    
    /**
     * 加载余额
     */
    private void loadBalance() {
        String apiKey = DataStore.getInstance().getApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            balanceValue.setText("请先设置API Key");
            return;
        }
        
        HttpClient.getInstance().setApiKey(apiKey);
        HttpClient.getInstance().get(ApiConfig.BASE_URL + ApiConfig.BALANCE, new ApiCallback<String>() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    final BalanceInfo balance = BalanceInfo.fromJson(json);
                    
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            balanceValue.setText(balance.getFormattedUsage());
                        }
                    });
                } catch (Exception e) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            balanceValue.setText("获取失败");
                        }
                    });
                }
            }
            
            @Override
            public void onError(String error) {
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        balanceValue.setText("获取失败");
                    }
                });
            }
        });
    }
    
    /**
     * 导出数据
     */
    private void exportData() {
        showCustomProgressDialog("正在导出...");
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                File exportFile = FileUtils.getExportFile(getContext());
                final boolean success = DataStore.getInstance().exportData(exportFile);
                
                final String message = success ? 
                    "已导出到：" + exportFile.getAbsolutePath() : 
                    "导出失败";
                
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        dismissProgressDialog();
                        showResultDialog(message, success);
                    }
                });
            }
        }).start();
    }
    
    /**
     * 导入数据
     */
    private void importData() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/json");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        activity.startActivityForResult(
            Intent.createChooser(intent, "选择备份文件"),
            REQUEST_CODE_IMPORT
        );
    }
    
    /**
     * 处理导入结果
     */
    public void handleImportResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_IMPORT && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                importDataFromUri(uri);
            }
        }
    }
    
    /**
     * 从URI导入数据
     */
    private void importDataFromUri(final Uri uri) {
        showCustomProgressDialog("正在导入...");
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // 复制到临时文件
                    File tempFile = new File(getContext().getCacheDir(), "import_temp.json");
                    java.io.InputStream is = getContext().getContentResolver().openInputStream(uri);
                    java.io.FileOutputStream fos = new java.io.FileOutputStream(tempFile);
                    
                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = is.read(buffer)) > 0) {
                        fos.write(buffer, 0, length);
                    }
                    
                    is.close();
                    fos.close();
                    
                    final boolean success = DataStore.getInstance().importData(tempFile);
                    tempFile.delete();
                    
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            dismissProgressDialog();
                            if (success) {
                                showResultDialog("导入成功，请重启应用", true);
                                loadData();
                            } else {
                                showResultDialog("导入失败", false);
                            }
                        }
                    });
                } catch (Exception e) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            dismissProgressDialog();
                            showResultDialog("导入失败", false);
                        }
                    });
                }
            }
        }).start();
    }
    
    /**
     * 显示自定义进度弹窗
     */
    private android.app.Dialog progressDialog;
    
    private void showCustomProgressDialog(String message) {
        progressDialog = new android.app.Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);
        
        FrameLayout container = new FrameLayout(getContext());
        container.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        container.setBackgroundColor(Color.parseColor("#80000000"));
        
        LinearLayout content = new LinearLayout(getContext());
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        contentParams.gravity = Gravity.CENTER;
        content.setLayoutParams(contentParams);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundDrawable(UiUtils.createRoundRectDrawable(Color.WHITE, 16, getContext()));
        content.setPadding(
            UiUtils.dpToPx(getContext(), 32),
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 32),
            UiUtils.dpToPx(getContext(), 24)
        );
        
        // 进度指示器
        TextView progressText = new TextView(getContext());
        progressText.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        progressText.setText(message);
        progressText.setTextSize(16);
        progressText.setTextColor(COLOR_TEXT_PRIMARY);
        content.addView(progressText);
        
        container.addView(content);
        progressDialog.setContentView(container);
        progressDialog.setCancelable(false);
        progressDialog.show();
    }
    
    private void dismissProgressDialog() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
    
    /**
     * 显示结果弹窗
     */
    private void showResultDialog(String message, boolean success) {
        final android.app.Dialog dialog = new android.app.Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);
        
        FrameLayout container = new FrameLayout(getContext());
        container.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        container.setBackgroundColor(Color.parseColor("#80000000"));
        
        LinearLayout content = new LinearLayout(getContext());
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        contentParams.gravity = Gravity.CENTER;
        content.setLayoutParams(contentParams);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundDrawable(UiUtils.createRoundRectDrawable(Color.WHITE, 16, getContext()));
        content.setPadding(
            UiUtils.dpToPx(getContext(), 32),
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 32),
            UiUtils.dpToPx(getContext(), 24)
        );
        
        TextView msgView = new TextView(getContext());
        msgView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        msgView.setText(message);
        msgView.setTextSize(16);
        msgView.setTextColor(COLOR_TEXT_PRIMARY);
        msgView.setGravity(Gravity.CENTER);
        content.addView(msgView);
        
        Button okBtn = new Button(getContext());
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
            UiUtils.dpToPx(getContext(), 120),
            UiUtils.dpToPx(getContext(), 44)
        );
        btnParams.topMargin = UiUtils.dpToPx(getContext(), 20);
        btnParams.gravity = Gravity.CENTER_HORIZONTAL;
        okBtn.setLayoutParams(btnParams);
        okBtn.setText("确定");
        okBtn.setTextSize(14);
        okBtn.setTextColor(Color.WHITE);
        okBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
            success ? COLOR_PRIMARY : Color.parseColor("#EF4444"), 12, getContext()));
        okBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        content.addView(okBtn);
        
        container.addView(content);
        dialog.setContentView(container);
        
        container.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        
        content.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // 阻止事件传递
            }
        });
        
        // 显示动画
        content.setScaleX(0.8f);
        content.setScaleY(0.8f);
        content.setAlpha(0f);
        dialog.show();
        content.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(200)
            .setInterpolator(new android.view.animation.DecelerateInterpolator())
            .start();
    }
    
    /**
     * 页面显示时调用
     */
    public void onShow() {
        loadData();
    }
}
