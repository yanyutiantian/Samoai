package com.samoai.ai.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 聊天历史记录实体类
 */
public class ChatHistory {
    private String id;
    private String characterId;
    private String characterName;
    private String lastMessage;
    private long lastTime;
    private List<Message> messages;
    private long createTime;
    
    public ChatHistory() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.createTime = System.currentTimeMillis();
        this.lastTime = System.currentTimeMillis();
        this.messages = new ArrayList<Message>();
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getCharacterId() {
        return characterId;
    }
    
    public void setCharacterId(String characterId) {
        this.characterId = characterId;
    }
    
    public String getCharacterName() {
        return characterName;
    }
    
    public void setCharacterName(String characterName) {
        this.characterName = characterName;
    }
    
    public String getLastMessage() {
        return lastMessage;
    }
    
    public void setLastMessage(String lastMessage) {
        this.lastMessage = lastMessage;
    }
    
    public long getLastTime() {
        return lastTime;
    }
    
    public void setLastTime(long lastTime) {
        this.lastTime = lastTime;
    }
    
    public List<Message> getMessages() {
        return messages;
    }
    
    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }
    
    public long getCreateTime() {
        return createTime;
    }
    
    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }
    
    /**
     * 添加消息并更新最后消息
     */
    public void addMessage(Message message) {
        if (messages == null) {
            messages = new ArrayList<Message>();
        }
        messages.add(message);
        lastMessage = message.getContent();
        lastTime = message.getTimestamp();
    }
    
    /**
     * 获取消息数量
     */
    public int getMessageCount() {
        return messages != null ? messages.size() : 0;
    }
    
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        try {
            json.put("id", id);
            json.put("character_id", characterId);
            json.put("character_name", characterName);
            json.put("last_message", lastMessage);
            json.put("last_time", lastTime);
            json.put("create_time", createTime);
            
            if (messages != null && !messages.isEmpty()) {
                JSONArray arr = new JSONArray();
                for (int i = 0; i < messages.size(); i++) {
                    arr.put(messages.get(i).toJson());
                }
                json.put("messages", arr);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
    
    public static ChatHistory fromJson(JSONObject json) {
        ChatHistory history = new ChatHistory();
        try {
            history.setId(json.optString("id", String.valueOf(System.currentTimeMillis())));
            history.setCharacterId(json.optString("character_id", ""));
            history.setCharacterName(json.optString("character_name", ""));
            history.setLastMessage(json.optString("last_message", ""));
            history.setLastTime(json.optLong("last_time", System.currentTimeMillis()));
            history.setCreateTime(json.optLong("create_time", System.currentTimeMillis()));
            
            JSONArray msgArr = json.optJSONArray("messages");
            if (msgArr != null) {
                List<Message> msgs = new ArrayList<Message>();
                for (int i = 0; i < msgArr.length(); i++) {
                    msgs.add(Message.fromJson(msgArr.optJSONObject(i)));
                }
                history.setMessages(msgs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return history;
    }
}
