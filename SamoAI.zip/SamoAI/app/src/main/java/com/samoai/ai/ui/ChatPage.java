package com.samoai.ai.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.samoai.ai.R;
import com.samoai.ai.adapter.CharacterAdapter;
import com.samoai.ai.adapter.MessageAdapter;
import com.samoai.ai.api.ApiCallback;
import com.samoai.ai.api.HttpClient;
import com.samoai.ai.api.StreamCallback;
import com.samoai.ai.manager.CharacterManager;
import com.samoai.ai.manager.HistoryManager;
import com.samoai.ai.model.CharacterCard;
import com.samoai.ai.model.ChatHistory;
import com.samoai.ai.model.Message;
import com.samoai.ai.store.DataStore;
import com.samoai.ai.utils.AnimUtils;
import com.samoai.ai.utils.JsonValidator;
import com.samoai.ai.utils.UiUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 聊天页面
 */
public class ChatPage extends LinearLayout {

    private Activity activity;
    private Handler mainHandler;

    // UI组件
    private LinearLayout headerLayout;
    private TextView titleView;
    private Button switchCharBtn;
    private Button importCharBtn;
    private Button newTopicBtn;
    private ListView messageListView;
    private LinearLayout inputLayout;
    private EditText inputEditText;
    private ImageButton sendBtn;
    private TextView streamingIndicator;

    // 适配器
    private MessageAdapter messageAdapter;

    // 状态
    private CharacterCard currentCharacter;
    private List<Message> currentMessages;
    private boolean isStreaming = false;
    private StringBuilder streamingContent;
    private Message streamingMessage;

    // 颜色
    private static final int COLOR_PRIMARY = Color.parseColor("#10A37F");
    private static final int COLOR_BG = Color.WHITE;
    private static final int COLOR_HEADER_BG = Color.WHITE;
    private static final int COLOR_INPUT_BG = Color.parseColor("#F9FAFB");
    private static final int COLOR_TEXT_PRIMARY = Color.parseColor("#111827");
    private static final int COLOR_TEXT_SECONDARY = Color.parseColor("#6B7280");
    private static final int COLOR_BORDER = Color.parseColor("#E5E7EB");

    private static final int REQUEST_CODE_IMPORT = 1001;

    public ChatPage(Activity activity) {
        super(activity);
        this.activity = activity;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.currentMessages = new ArrayList<Message>();
        init();
    }

    private void init() {
        setLayoutParams(new LayoutParams(
                            LayoutParams.MATCH_PARENT,
                            LayoutParams.MATCH_PARENT
                        ));
        setOrientation(VERTICAL);
        setBackgroundColor(COLOR_BG);

        createHeader();
        createMessageList();
        createInputArea();

        // 初始化数据
        loadCurrentCharacter();
        loadMessages();
    }

    /**
     * 创建顶部导航栏
     */
    private void createHeader() {
        headerLayout = new LinearLayout(getContext());
        headerLayout.setLayoutParams(new LayoutParams(
                                         LayoutParams.MATCH_PARENT,
                                         UiUtils.dpToPx(getContext(), 56)
                                     ));
        headerLayout.setOrientation(HORIZONTAL);
        headerLayout.setGravity(Gravity.CENTER_VERTICAL);
        headerLayout.setBackgroundColor(COLOR_HEADER_BG);
        headerLayout.setPadding(
            UiUtils.dpToPx(getContext(), 8),
            0,
            UiUtils.dpToPx(getContext(), 8),
            0
        );

        // 切换角色按钮
        switchCharBtn = createHeaderButton("角色", "switch");
        switchCharBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    AnimUtils.buttonClick(v);
                    showCharacterSwitchDialog();
                }
            });

        // 标题
        titleView = new TextView(getContext());
        LayoutParams titleParams = new LayoutParams(
            0,
            LayoutParams.WRAP_CONTENT,
            1
        );
        titleParams.leftMargin = UiUtils.dpToPx(getContext(), 8);
        titleParams.rightMargin = UiUtils.dpToPx(getContext(), 8);
        titleView.setLayoutParams(titleParams);
        titleView.setTextSize(17);
        titleView.setTextColor(COLOR_TEXT_PRIMARY);
        titleView.setGravity(Gravity.CENTER);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);

        // 导入角色按钮
        importCharBtn = createHeaderButton("导入", "import");
        importCharBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    AnimUtils.buttonClick(v);
                    importCharacterCard();
                }
            });

        // 新建话题按钮
        newTopicBtn = createHeaderButton("新会话", "new");
        newTopicBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    AnimUtils.buttonClick(v);
                    newTopic();
                }
            });

        headerLayout.addView(switchCharBtn);
        headerLayout.addView(titleView);
        headerLayout.addView(importCharBtn);
        headerLayout.addView(newTopicBtn);

        addView(headerLayout);

        // 添加分割线
        View divider = new View(getContext());
        divider.setLayoutParams(new LayoutParams(
                                    LayoutParams.MATCH_PARENT,
                                    UiUtils.dpToPx(getContext(), 1)
                                ));
        divider.setBackgroundColor(COLOR_BORDER);
        addView(divider);
    }

    private Button createHeaderButton(String text, String iconType) {
        Button btn = new Button(getContext());
        btn.setLayoutParams(new LayoutParams(
                                UiUtils.dpToPx(getContext(), 56),
                                UiUtils.dpToPx(getContext(), 40)
                            ));
        btn.setText(text);
        btn.setTextSize(12);
        btn.setTextColor(COLOR_PRIMARY);
        btn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
                                      Color.parseColor("#ECFDF5"), 8, getContext()));
        btn.setAllCaps(false);
        btn.setPadding(0, 0, 0, 0);
        return btn;
    }

    /**
     * 创建消息列表
     */
    private void createMessageList() {
        FrameLayout listContainer = new FrameLayout(getContext());
        listContainer.setLayoutParams(new LayoutParams(
                                          LayoutParams.MATCH_PARENT,
                                          0,
                                          1
                                      ));

        messageListView = new ListView(getContext());
        messageListView.setLayoutParams(new FrameLayout.LayoutParams(
                                            FrameLayout.LayoutParams.MATCH_PARENT,
                                            FrameLayout.LayoutParams.MATCH_PARENT
                                        ));
        messageListView.setDivider(null);
        messageListView.setDividerHeight(0);
        messageListView.setCacheColorHint(Color.TRANSPARENT);
        messageListView.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));

        messageAdapter = new MessageAdapter(getContext());
        messageAdapter.setOnMessageLongClickListener(new MessageAdapter.OnMessageLongClickListener() {
                @Override
                public void onMessageLongClick(Message message, int position) {
                    copyMessageToClipboard(message);
                }
            });
        messageListView.setAdapter(messageAdapter);

        // 流式输出指示器
        streamingIndicator = new TextView(getContext());
        FrameLayout.LayoutParams indicatorParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        indicatorParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        indicatorParams.bottomMargin = UiUtils.dpToPx(getContext(), 8);
        streamingIndicator.setLayoutParams(indicatorParams);
        streamingIndicator.setText("AI正在输入...");
        streamingIndicator.setTextSize(12);
        streamingIndicator.setTextColor(COLOR_TEXT_SECONDARY);
        streamingIndicator.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
                                                     Color.parseColor("#F3F4F6"), 12, getContext()));
        streamingIndicator.setPadding(
            UiUtils.dpToPx(getContext(), 12),
            UiUtils.dpToPx(getContext(), 6),
            UiUtils.dpToPx(getContext(), 12),
            UiUtils.dpToPx(getContext(), 6)
        );
        streamingIndicator.setVisibility(GONE);

        listContainer.addView(messageListView);
        listContainer.addView(streamingIndicator);

        addView(listContainer);
    }

    /**
     * 创建输入区域
     */
    private void createInputArea() {
        inputLayout = new LinearLayout(getContext());
        inputLayout.setLayoutParams(new LayoutParams(
                                        LayoutParams.MATCH_PARENT,
                                        LayoutParams.WRAP_CONTENT
                                    ));
        inputLayout.setOrientation(HORIZONTAL);
        inputLayout.setGravity(Gravity.CENTER_VERTICAL);
        inputLayout.setBackgroundColor(COLOR_INPUT_BG);
        inputLayout.setPadding(
            UiUtils.dpToPx(getContext(), 12),
            UiUtils.dpToPx(getContext(), 8),
            UiUtils.dpToPx(getContext(), 12),
            UiUtils.dpToPx(getContext(), 8)
        );

        // 输入框
        inputEditText = new EditText(getContext());
        LayoutParams inputParams = new LayoutParams(
            0,
            LayoutParams.WRAP_CONTENT,
            1
        );
        inputEditText.setLayoutParams(inputParams);
        inputEditText.setHint("输入消息...");
        inputEditText.setTextSize(15);
        inputEditText.setTextColor(COLOR_TEXT_PRIMARY);
        inputEditText.setHintTextColor(COLOR_TEXT_SECONDARY);
        inputEditText.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
                                                Color.WHITE, 20, getContext()));
        inputEditText.setPadding(
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 10),
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 10)
        );
        inputEditText.setMaxLines(5);
        inputEditText.setMinHeight(UiUtils.dpToPx(getContext(), 44));

        // 发送按钮 - 使用ic_send_circle.png图片
        sendBtn = new ImageButton(getContext());
        LayoutParams sendParams = new LayoutParams(
            UiUtils.dpToPx(getContext(), 44),
            UiUtils.dpToPx(getContext(), 44)
        );
        sendParams.leftMargin = UiUtils.dpToPx(getContext(), 8);
        sendBtn.setLayoutParams(sendParams);
        sendBtn.setBackgroundDrawable(UiUtils.createCircleDrawable(COLOR_PRIMARY));
        // 使用R.drawable.ic_send_circle加载图片资源
        sendBtn.setImageResource(R.drawable.ic_send_circle);
        sendBtn.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        sendBtn.setPadding(
            UiUtils.dpToPx(getContext(), 10),
            UiUtils.dpToPx(getContext(), 10),
            UiUtils.dpToPx(getContext(), 10),
            UiUtils.dpToPx(getContext(), 10)
        );
        sendBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    AnimUtils.buttonClick(v);
                    sendMessage();
                }
            });

        inputLayout.addView(inputEditText);
        inputLayout.addView(sendBtn);

        addView(inputLayout);
    }

    /**
     * 加载当前角色卡
     */
    private void loadCurrentCharacter() {
        currentCharacter = CharacterManager.getInstance().getCurrentCharacter();
        if (currentCharacter == null) {
            currentCharacter = CharacterManager.getInstance().getDefaultCharacter();
            CharacterManager.getInstance().setCurrentCharacter(currentCharacter);
        }
        updateTitle();
    }

    /**
     * 加载消息
     */
    private void loadMessages() {
        currentMessages = DataStore.getInstance().getCurrentMessages();
        if (currentMessages == null) {
            currentMessages = new ArrayList<Message>();
        }
        if (currentMessages.isEmpty()) {
            // 添加角色卡的首次问候语
            if (currentCharacter != null && currentCharacter.getFirstMes() != null 
                && !currentCharacter.getFirstMes().isEmpty()) {
                Message welcomeMsg = new Message(Message.TYPE_AI, currentCharacter.getFirstMes());
                currentMessages.add(welcomeMsg);
                saveMessages();
            }
        }
        messageAdapter.setMessages(currentMessages);
        scrollToBottom();
    }

    /**
     * 更新标题
     */
    private void updateTitle() {
        if (currentCharacter != null) {
            titleView.setText(currentCharacter.getName());
        } else {
            titleView.setText("Samoai");
        }
    }

    /**
     * 发送消息 - 修复：只添加到currentMessages，不重复添加到adapter
     */
    private void sendMessage() {
        String content = inputEditText.getText().toString().trim();
        if (content.isEmpty() || isStreaming) {
            return;
        }

        // 隐藏键盘
        UiUtils.hideKeyboard(inputEditText);

        // 添加用户消息 - 只添加到currentMessages，通过setMessages刷新列表
        Message userMessage = new Message(Message.TYPE_USER, content);
        currentMessages.add(userMessage);
        // BUG修复：不要调用messageAdapter.addMessage(userMessage)，改用setMessages
        messageAdapter.setMessages(currentMessages);
        saveMessages();

        // 清空输入框
        inputEditText.setText("");

        // 滚动到底部
        scrollToBottom();

        // 发送请求
        sendChatRequest();
    }

    /**
     * 发送聊天请求 - 修复：流式消息只添加一次
     */
    private void sendChatRequest() {
        if (currentCharacter == null) {
            UiUtils.showToast(getContext(), "请先选择角色卡");
            return;
        }

        String apiKey = DataStore.getInstance().getApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            UiUtils.showToast(getContext(), "请先设置API Key");
            return;
        }

        HttpClient.getInstance().setApiKey(apiKey);

        isStreaming = true;
        streamingContent = new StringBuilder();
        streamingMessage = new Message(Message.TYPE_AI, "");
        streamingMessage.setStreaming(true);
        // 添加流式消息到currentMessages
        currentMessages.add(streamingMessage);
        // BUG修复：不要调用messageAdapter.addMessage(streamingMessage)，改用setMessages
        messageAdapter.setMessages(currentMessages);

        streamingIndicator.setVisibility(VISIBLE);
        AnimUtils.createPulseAnimation(streamingIndicator).start();

        String model = DataStore.getInstance().getCurrentModel();
        String systemPrompt = currentCharacter.buildSystemPrompt();

        HttpClient.getInstance().streamChat(model, currentMessages, systemPrompt, new StreamCallback() {
                @Override
                public void onContent(final String content) {
                    mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                streamingContent.append(content);
                                streamingMessage.setContent(streamingContent.toString());
                                // 使用updateLastMessage只更新最后一项，避免重复添加
                                messageAdapter.updateLastMessage(streamingContent.toString());
                                scrollToBottom();
                            }
                        });
                }

                @Override
                public void onComplete() {
                    mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                isStreaming = false;
                                streamingMessage.setStreaming(false);
                                streamingIndicator.setVisibility(GONE);
                                saveMessages();
                            }
                        });
                }

                @Override
                public void onError(final String error) {
                    mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                isStreaming = false;
                                streamingIndicator.setVisibility(GONE);

                                // 移除流式消息
                                if (!currentMessages.isEmpty() && currentMessages.get(currentMessages.size() - 1).isStreaming()) {
                                    currentMessages.remove(currentMessages.size() - 1);
                                }

                                // 显示错误
                                Message errorMsg = new Message(Message.TYPE_SYSTEM, error);
                                currentMessages.add(errorMsg);
                                messageAdapter.setMessages(currentMessages);
                                saveMessages();
                                scrollToBottom();

                                UiUtils.showToast(getContext(), error);
                            }
                        });
                }
            });
    }

    /**
     * 保存消息
     */
    private void saveMessages() {
        DataStore.getInstance().saveCurrentMessages(currentMessages);
    }

    /**
     * 滚动到底部
     */
    private void scrollToBottom() {
        if (messageListView != null && messageAdapter.getCount() > 0) {
            messageListView.post(new Runnable() {
                    @Override
                    public void run() {
                        messageListView.setSelection(messageAdapter.getCount() - 1);
                    }
                });
        }
    }

    /**
     * 新建话题
     */
    private void newTopic() {
        // 归档当前对话
        if (!currentMessages.isEmpty()) {
            HistoryManager.getInstance().archiveCurrentChat(
                currentCharacter != null ? currentCharacter.getId() : "",
                currentCharacter != null ? currentCharacter.getName() : "AI助手",
                new ArrayList<Message>(currentMessages)
            );
        }

        // 清空当前消息
        currentMessages.clear();
        messageAdapter.clear();
        DataStore.getInstance().clearCurrentMessages();

        // 添加新的欢迎消息
        if (currentCharacter != null && currentCharacter.getFirstMes() != null 
            && !currentCharacter.getFirstMes().isEmpty()) {
            Message welcomeMsg = new Message(Message.TYPE_AI, currentCharacter.getFirstMes());
            currentMessages.add(welcomeMsg);
            messageAdapter.setMessages(currentMessages);
            saveMessages();
        }

        UiUtils.showToast(getContext(), "已新建话题");
    }

    /**
     * 显示角色切换对话框（使用自定义美化弹窗）
     */
    private void showCharacterSwitchDialog() {
        // 归档当前对话
        if (!currentMessages.isEmpty()) {
            HistoryManager.getInstance().archiveCurrentChat(
                currentCharacter != null ? currentCharacter.getId() : "",
                currentCharacter != null ? currentCharacter.getName() : "Samoai",
                new ArrayList<Message>(currentMessages)
            );
        }

        final List<CharacterCard> characters = CharacterManager.getInstance().getCharacters();
        if (characters.isEmpty()) {
            UiUtils.showToast(getContext(), "没有可用的角色卡");
            return;
        }

        // 创建自定义弹窗
        final android.app.Dialog dialog = new android.app.Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);

        // 创建背景遮罩
        FrameLayout dialogContainer = new FrameLayout(getContext());
        dialogContainer.setLayoutParams(new FrameLayout.LayoutParams(
                                            FrameLayout.LayoutParams.MATCH_PARENT,
                                            FrameLayout.LayoutParams.MATCH_PARENT
                                        ));
        dialogContainer.setBackgroundColor(Color.parseColor("#80000000"));

        // 创建弹窗内容
        LinearLayout dialogContent = new LinearLayout(getContext());
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        contentParams.gravity = Gravity.BOTTOM;
        contentParams.leftMargin = UiUtils.dpToPx(getContext(), 16);
        contentParams.rightMargin = UiUtils.dpToPx(getContext(), 16);
        contentParams.bottomMargin = UiUtils.dpToPx(getContext(), 16);
        dialogContent.setLayoutParams(contentParams);
        dialogContent.setOrientation(LinearLayout.VERTICAL);
        dialogContent.setBackgroundDrawable(UiUtils.createRoundRectDrawable(Color.WHITE, 16, getContext()));
        dialogContent.setPadding(
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16),
            UiUtils.dpToPx(getContext(), 16)
        );

        // 标题
        TextView titleView = new TextView(getContext());
        titleView.setLayoutParams(new LinearLayout.LayoutParams(
                                      LinearLayout.LayoutParams.MATCH_PARENT,
                                      LinearLayout.LayoutParams.WRAP_CONTENT
                                  ));
        titleView.setText("选择角色卡");
        titleView.setTextSize(18);
        titleView.setTextColor(COLOR_TEXT_PRIMARY);
        titleView.setGravity(Gravity.CENTER);
        titleView.setPadding(0, 0, 0, UiUtils.dpToPx(getContext(), 16));
        dialogContent.addView(titleView);

        // 创建列表
        final ListView listView = new ListView(getContext());
        listView.setLayoutParams(new LinearLayout.LayoutParams(
                                     LinearLayout.LayoutParams.MATCH_PARENT,
                                     UiUtils.dpToPx(getContext(), 300)
                                 ));
        listView.setDivider(null);
        listView.setDividerHeight(0);

        final CharacterAdapter adapter = new CharacterAdapter(getContext());
        adapter.setCharacters(characters);
        adapter.setSelectedId(currentCharacter != null ? currentCharacter.getId() : null);

        adapter.setOnCharacterClickListener(new CharacterAdapter.OnCharacterClickListener() {
                @Override
                public void onCharacterClick(CharacterCard character, int position) {
                    dialog.dismiss();
                    switchCharacter(character);
                }
            });

        listView.setAdapter(adapter);
        dialogContent.addView(listView);

        // 取消按钮
        Button cancelBtn = new Button(getContext());
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 48)
        );
        cancelParams.topMargin = UiUtils.dpToPx(getContext(), 16);
        cancelBtn.setLayoutParams(cancelParams);
        cancelBtn.setText("取消");
        cancelBtn.setTextSize(16);
        cancelBtn.setTextColor(COLOR_TEXT_SECONDARY);
        cancelBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
                                            Color.parseColor("#F3F4F6"), 12, getContext()));
        cancelBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        dialogContent.addView(cancelBtn);

        dialogContainer.addView(dialogContent);
        dialog.setContentView(dialogContainer);

        // 点击背景关闭
        dialogContainer.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

        // 阻止点击内容区域关闭
        dialogContent.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 不处理，阻止事件传递
                }
            });

        // 显示动画
        dialogContent.setTranslationY(UiUtils.dpToPx(getContext(), 400));
        dialogContent.setAlpha(0f);
        dialog.show();
        dialogContent.animate()
            .translationY(0)
            .alpha(1f)
            .setDuration(250)
            .setInterpolator(new android.view.animation.DecelerateInterpolator())
            .start();
    }

    /**
     * 切换角色
     */
    private void switchCharacter(CharacterCard character) {
        if (character == null || (currentCharacter != null && character.getId().equals(currentCharacter.getId()))) {
            return;
        }

        // 归档当前对话
        if (!currentMessages.isEmpty()) {
            HistoryManager.getInstance().archiveCurrentChat(
                currentCharacter.getId(),
                currentCharacter.getName(),
                new ArrayList<Message>(currentMessages)
            );
        }

        // 切换角色
        currentCharacter = character;
        CharacterManager.getInstance().setCurrentCharacter(character);
        updateTitle();

        // 清空消息并加载新角色的欢迎语
        currentMessages.clear();
        messageAdapter.clear();

        if (character.getFirstMes() != null && !character.getFirstMes().isEmpty()) {
            Message welcomeMsg = new Message(Message.TYPE_AI, character.getFirstMes());
            currentMessages.add(welcomeMsg);
            messageAdapter.setMessages(currentMessages);
        }

        saveMessages();
        UiUtils.showToast(getContext(), "已切换到：" + character.getName());
    }

    /**
     * 导入角色卡
     */
    private void importCharacterCard() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/json");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        activity.startActivityForResult(
            Intent.createChooser(intent, "选择角色卡文件"),
            REQUEST_CODE_IMPORT
        );
    }

    /**
     * 处理导入结果
     */
    public void handleImportResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_IMPORT && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                importCharacterFromUri(uri);
            }
        }
    }

    /**
     * 从URI导入角色卡
     */
    private void importCharacterFromUri(Uri uri) {
        try {
            String json = com.samoai.ai.utils.FileUtils.readTextFromUri(getContext(), uri);

            if (!JsonValidator.isValidSillyTavernCard(json)) {
                showErrorDialog("导入失败，非有效角色卡");
                return;
            }

            CharacterCard card = JsonValidator.parseSillyTavernCard(json);
            if (card != null) {
                CharacterManager.getInstance().addCharacter(card);
                showSuccessDialog("导入成功：" + card.getName());
            } else {
                showErrorDialog("导入失败，非有效角色卡");
            }
        } catch (Exception e) {
            showErrorDialog("导入失败，非有效角色卡");
        }
    }

    /**
     * 显示成功弹窗
     */
    private void showSuccessDialog(String message) {
        showCustomDialog(message, COLOR_PRIMARY);
    }

    /**
     * 显示错误弹窗
     */
    private void showErrorDialog(String message) {
        showCustomDialog(message, Color.parseColor("#EF4444"));
    }

    /**
     * 显示自定义弹窗
     */
    private void showCustomDialog(String message, int accentColor) {
        final android.app.Dialog dialog = new android.app.Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);

        FrameLayout container = new FrameLayout(getContext());
        container.setLayoutParams(new FrameLayout.LayoutParams(
                                      FrameLayout.LayoutParams.MATCH_PARENT,
                                      FrameLayout.LayoutParams.MATCH_PARENT
                                  ));
        container.setBackgroundColor(Color.parseColor("#80000000"));

        LinearLayout content = new LinearLayout(getContext());
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        contentParams.gravity = Gravity.CENTER;
        content.setLayoutParams(contentParams);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundDrawable(UiUtils.createRoundRectDrawable(Color.WHITE, 16, getContext()));
        content.setPadding(
            UiUtils.dpToPx(getContext(), 32),
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 32),
            UiUtils.dpToPx(getContext(), 24)
        );

        TextView msgView = new TextView(getContext());
        msgView.setLayoutParams(new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT
                                ));
        msgView.setText(message);
        msgView.setTextSize(16);
        msgView.setTextColor(COLOR_TEXT_PRIMARY);
        msgView.setGravity(Gravity.CENTER);
        content.addView(msgView);

        Button okBtn = new Button(getContext());
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
            UiUtils.dpToPx(getContext(), 120),
            UiUtils.dpToPx(getContext(), 44)
        );
        btnParams.topMargin = UiUtils.dpToPx(getContext(), 20);
        btnParams.gravity = Gravity.CENTER_HORIZONTAL;
        okBtn.setLayoutParams(btnParams);
        okBtn.setText("确定");
        okBtn.setTextSize(14);
        okBtn.setTextColor(Color.WHITE);
        okBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(accentColor, 12, getContext()));
        okBtn.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        content.addView(okBtn);

        container.addView(content);
        dialog.setContentView(container);

        container.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

        content.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 阻止事件传递
                }
            });

        // 显示动画
        content.setScaleX(0.8f);
        content.setScaleY(0.8f);
        content.setAlpha(0f);
        dialog.show();
        content.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(200)
            .setInterpolator(new android.view.animation.DecelerateInterpolator())
            .start();
    }

    /**
     * 复制消息到剪贴板
     */
    private void copyMessageToClipboard(Message message) {
        ClipboardManager clipboard = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            ClipData clip = ClipData.newPlainText("message", message.getContent());
            clipboard.setPrimaryClip(clip);
            UiUtils.showToast(getContext(), "已复制");
        }
    }

    /**
     * 页面显示时调用
     */
    public void onShow() {
        // 刷新数据
        loadCurrentCharacter();
    }
}

