package com.samoai.ai;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.samoai.ai.R;
import com.samoai.ai.model.ChatHistory;
import com.samoai.ai.store.DataStore;
import com.samoai.ai.ui.ChatPage;
import com.samoai.ai.ui.HistoryPage;
import com.samoai.ai.ui.ProfilePage;
import com.samoai.ai.utils.AnimUtils;
import com.samoai.ai.utils.UiUtils;

/**
 * 主Activity
 */
public class MainActivity extends Activity {

    // Tab索引
    private static final int TAB_CHAT = 0;
    private static final int TAB_HISTORY = 1;
    private static final int TAB_PROFILE = 2;

    // UI组件
    private FrameLayout contentContainer;
    private LinearLayout tabLayout;
    private LinearLayout[] tabItems;
    private ImageView[] tabIcons;
    private TextView[] tabLabels;

    // 页面
    private ChatPage chatPage;
    private HistoryPage historyPage;
    private ProfilePage profilePage;

    // 当前Tab
    private int currentTab = -1;

    // 颜色
    private static final int COLOR_PRIMARY = Color.parseColor("#10A37F");
    private static final int COLOR_UNSELECTED = Color.parseColor("#9CA3AF");
    private static final int COLOR_BG = Color.WHITE;
    private static final int COLOR_TAB_BG = Color.WHITE;
    private static final int COLOR_BORDER = Color.parseColor("#E5E7EB");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 初始化数据存储
        DataStore.getInstance().init(this);

        // 创建根布局
        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setLayoutParams(new LinearLayout.LayoutParams(
                                       LinearLayout.LayoutParams.MATCH_PARENT,
                                       LinearLayout.LayoutParams.MATCH_PARENT
                                   ));
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(COLOR_BG);

        // 创建内容区域
        createContentContainer(rootLayout);

        // 创建底部Tab栏
        createTabLayout(rootLayout);

        setContentView(rootLayout);

        // 默认显示聊天页
        switchTab(TAB_CHAT);
    }

    /**
     * 创建内容容器
     */
    private void createContentContainer(LinearLayout root) {
        contentContainer = new FrameLayout(this);
        contentContainer.setLayoutParams(new LinearLayout.LayoutParams(
                                             LinearLayout.LayoutParams.MATCH_PARENT,
                                             0,
                                             1
                                         ));
        root.addView(contentContainer);
    }

    /**
     * 创建底部Tab栏
     */
    private void createTabLayout(LinearLayout root) {
        // 添加顶部分割线
        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.MATCH_PARENT,
                                    UiUtils.dpToPx(this, 1)
                                ));
        divider.setBackgroundColor(COLOR_BORDER);
        root.addView(divider);

        tabLayout = new LinearLayout(this);
        tabLayout.setLayoutParams(new LinearLayout.LayoutParams(
                                      LinearLayout.LayoutParams.MATCH_PARENT,
                                      UiUtils.dpToPx(this, 56)
                                  ));
        tabLayout.setOrientation(LinearLayout.HORIZONTAL);
        tabLayout.setBackgroundColor(COLOR_TAB_BG);
        tabLayout.setGravity(Gravity.CENTER_VERTICAL);

        // 创建三个Tab
        tabItems = new LinearLayout[3];
        tabIcons = new ImageView[3];
        tabLabels = new TextView[3];

        // 聊天Tab
        tabItems[TAB_CHAT] = createTabItem("聊天", TAB_CHAT, R.drawable.ic_chat);
        // 历史Tab
        tabItems[TAB_HISTORY] = createTabItem("历史", TAB_HISTORY, R.drawable.ic_history);
        // 我的Tab
        tabItems[TAB_PROFILE] = createTabItem("我的", TAB_PROFILE, R.drawable.ic_account_circle_outline);

        for (int i = 0; i < 3; i++) {
            tabLayout.addView(tabItems[i]);
        }

        root.addView(tabLayout);
    }

    /**
     * 创建Tab项
     */
    private LinearLayout createTabItem(String label, final int index, int iconResId) {
        LinearLayout item = new LinearLayout(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.MATCH_PARENT,
            1
        );
        item.setLayoutParams(params);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setClickable(true);
        item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AnimUtils.buttonClick(v);
                    switchTab(index);
                }
            });

        // 图标
        ImageView iconView = new ImageView(this);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(
            UiUtils.dpToPx(this, 24),
            UiUtils.dpToPx(this, 24)
        );
        iconView.setLayoutParams(iconParams);
        iconView.setImageResource(iconResId);

        // 标签
        TextView text = new TextView(this);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        textParams.topMargin = UiUtils.dpToPx(this, 2);
        text.setLayoutParams(textParams);
        text.setText(label);
        text.setTextSize(11);
        text.setTextColor(COLOR_UNSELECTED);

        item.addView(iconView);
        item.addView(text);

        tabIcons[index] = iconView;
        tabLabels[index] = text;

        return item;
    }

    /**
     * 切换Tab
     */
    private void switchTab(int newTab) {
        if (newTab == currentTab) {
            return;
        }

        boolean toRight = newTab > currentTab;

        // 更新Tab样式
        updateTabStyle(currentTab, false);
        updateTabStyle(newTab, true);

        // 切换页面
        View fromView = null;
        View toView = null;

        if (currentTab >= 0) {
            switch (currentTab) {
                case TAB_CHAT:
                    fromView = chatPage;
                    break;
                case TAB_HISTORY:
                    fromView = historyPage;
                    break;
                case TAB_PROFILE:
                    fromView = profilePage;
                    break;
            }
        }

        switch (newTab) {
            case TAB_CHAT:
                if (chatPage == null) {
                    chatPage = new ChatPage(this);
                }
                toView = chatPage;
                chatPage.onShow();
                break;
            case TAB_HISTORY:
                if (historyPage == null) {
                    historyPage = new HistoryPage(this);
                    historyPage.setOnHistorySelectListener(new HistoryPage.OnHistorySelectListener() {
                            @Override
                            public void onHistorySelected(ChatHistory history) {
                                // 切换到聊天页并继续对话
                                switchTab(TAB_CHAT);
                            }
                        });
                }
                toView = historyPage;
                historyPage.onShow();
                break;
            case TAB_PROFILE:
                if (profilePage == null) {
                    profilePage = new ProfilePage(this);
                }
                toView = profilePage;
                profilePage.onShow();
                break;
        }

        // 执行切换动画
        if (toView != null) {
            if (toView.getParent() == null) {
                contentContainer.addView(toView);
            }

            // 动画切换
            AnimUtils.tabSwitch(fromView, toView, toRight);

            // 确保新页面在最上层
            toView.bringToFront();
        }

        currentTab = newTab;
    }

    /**
     * 更新Tab样式（选中变色）
     */
    private void updateTabStyle(int tabIndex, boolean selected) {
        if (tabIndex < 0 || tabIndex >= tabLabels.length) {
            return;
        }

        int color = selected ? COLOR_PRIMARY : COLOR_UNSELECTED;
        tabLabels[tabIndex].setTextColor(color);
        tabIcons[tabIndex].setColorFilter(color);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // 转发给各页面处理
        if (chatPage != null) {
            chatPage.handleImportResult(requestCode, resultCode, data);
        }
        if (profilePage != null) {
            profilePage.handleImportResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 刷新当前页面
        switch (currentTab) {
            case TAB_CHAT:
                if (chatPage != null) chatPage.onShow();
                break;
            case TAB_HISTORY:
                if (historyPage != null) historyPage.onShow();
                break;
            case TAB_PROFILE:
                if (profilePage != null) profilePage.onShow();
                break;
        }
    }
}

