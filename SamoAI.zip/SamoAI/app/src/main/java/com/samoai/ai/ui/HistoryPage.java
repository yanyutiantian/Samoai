package com.samoai.ai.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.samoai.ai.adapter.HistoryAdapter;
import com.samoai.ai.manager.HistoryManager;
import com.samoai.ai.model.ChatHistory;
import com.samoai.ai.model.Message;
import com.samoai.ai.store.DataStore;
import com.samoai.ai.utils.AnimUtils;
import com.samoai.ai.utils.UiUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * 历史记录页面
 */
public class HistoryPage extends LinearLayout {
    
    // UI组件
    private LinearLayout headerLayout;
    private TextView titleView;
    private Button clearBtn;
    private ListView historyListView;
    private TextView emptyView;
    
    // 适配器
    private HistoryAdapter historyAdapter;
    
    // 回调
    private OnHistorySelectListener selectListener;
    
    // 颜色
    private static final int COLOR_PRIMARY = Color.parseColor("#10A37F");
    private static final int COLOR_BG = Color.WHITE;
    private static final int COLOR_HEADER_BG = Color.WHITE;
    private static final int COLOR_TEXT_PRIMARY = Color.parseColor("#111827");
    private static final int COLOR_TEXT_SECONDARY = Color.parseColor("#6B7280");
    private static final int COLOR_BORDER = Color.parseColor("#E5E7EB");
    private static final int COLOR_EMPTY_TEXT = Color.parseColor("#9CA3AF");
    
    public interface OnHistorySelectListener {
        void onHistorySelected(ChatHistory history);
    }
    
    public HistoryPage(android.content.Context context) {
        super(context);
        init();
    }
    
    public void setOnHistorySelectListener(OnHistorySelectListener listener) {
        this.selectListener = listener;
    }
    
    private void init() {
        setLayoutParams(new LayoutParams(
            LayoutParams.MATCH_PARENT,
            LayoutParams.MATCH_PARENT
        ));
        setOrientation(VERTICAL);
        setBackgroundColor(COLOR_BG);
        
        createHeader();
        createHistoryList();
        
        // 加载数据
        loadHistories();
    }
    
    /**
     * 创建顶部导航栏
     */
    private void createHeader() {
        headerLayout = new LinearLayout(getContext());
        headerLayout.setLayoutParams(new LayoutParams(
            LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 56)
        ));
        headerLayout.setOrientation(HORIZONTAL);
        headerLayout.setGravity(Gravity.CENTER_VERTICAL);
        headerLayout.setBackgroundColor(COLOR_HEADER_BG);
        headerLayout.setPadding(
            UiUtils.dpToPx(getContext(), 16),
            0,
            UiUtils.dpToPx(getContext(), 16),
            0
        );
        
        // 标题
        titleView = new TextView(getContext());
        LayoutParams titleParams = new LayoutParams(
            0,
            LayoutParams.WRAP_CONTENT,
            1
        );
        titleView.setLayoutParams(titleParams);
        titleView.setText("历史记录");
        titleView.setTextSize(18);
        titleView.setTextColor(COLOR_TEXT_PRIMARY);
        titleView.setGravity(Gravity.CENTER);
        
        // 清空按钮
        clearBtn = new Button(getContext());
        LayoutParams clearParams = new LayoutParams(
            LayoutParams.WRAP_CONTENT,
            UiUtils.dpToPx(getContext(), 36)
        );
        clearBtn.setLayoutParams(clearParams);
        clearBtn.setText("清空");
        clearBtn.setTextSize(13);
        clearBtn.setTextColor(COLOR_PRIMARY);
        clearBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
            Color.parseColor("#ECFDF5"), 8, getContext()));
        clearBtn.setPadding(
            UiUtils.dpToPx(getContext(), 16),
            0,
            UiUtils.dpToPx(getContext(), 16),
            0
        );
        clearBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                AnimUtils.buttonClick(v);
                showClearAllDialog();
            }
        });
        
        headerLayout.addView(titleView);
        headerLayout.addView(clearBtn);
        
        addView(headerLayout);
        
        // 添加分割线
        View divider = new View(getContext());
        divider.setLayoutParams(new LayoutParams(
            LayoutParams.MATCH_PARENT,
            UiUtils.dpToPx(getContext(), 1)
        ));
        divider.setBackgroundColor(COLOR_BORDER);
        addView(divider);
    }
    
    /**
     * 创建历史列表
     */
    private void createHistoryList() {
        FrameLayout listContainer = new FrameLayout(getContext());
        listContainer.setLayoutParams(new LayoutParams(
            LayoutParams.MATCH_PARENT,
            0,
            1
        ));
        
        historyListView = new ListView(getContext());
        historyListView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        historyListView.setDivider(null);
        historyListView.setDividerHeight(0);
        historyListView.setCacheColorHint(Color.TRANSPARENT);
        historyListView.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        
        historyAdapter = new HistoryAdapter(getContext());
        historyAdapter.setOnHistoryClickListener(new HistoryAdapter.OnHistoryClickListener() {
            @Override
            public void onHistoryClick(ChatHistory history, int position) {
                if (selectListener != null) {
                    continueChat(history);
                }
            }
        });
        historyAdapter.setOnHistoryDeleteListener(new HistoryAdapter.OnHistoryDeleteListener() {
            @Override
            public void onHistoryDelete(ChatHistory history, int position) {
                showDeleteDialog(history, position);
            }
        });
        
        historyListView.setAdapter(historyAdapter);
        
        // 空视图
        emptyView = new TextView(getContext());
        FrameLayout.LayoutParams emptyParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        emptyParams.gravity = Gravity.CENTER;
        emptyView.setLayoutParams(emptyParams);
        emptyView.setText("暂无历史记录");
        emptyView.setTextSize(16);
        emptyView.setTextColor(COLOR_EMPTY_TEXT);
        emptyView.setVisibility(GONE);
        
        listContainer.addView(historyListView);
        listContainer.addView(emptyView);
        
        addView(listContainer);
    }
    
    /**
     * 加载历史记录
     */
    private void loadHistories() {
        List<ChatHistory> histories = HistoryManager.getInstance().getHistories();
        historyAdapter.setHistories(histories);
        
        // 显示/隐藏空视图
        if (histories == null || histories.isEmpty()) {
            emptyView.setVisibility(VISIBLE);
            historyListView.setVisibility(GONE);
        } else {
            emptyView.setVisibility(GONE);
            historyListView.setVisibility(VISIBLE);
        }
    }
    
    /**
     * 显示删除对话框（美化版）
     */
    private void showDeleteDialog(final ChatHistory history, final int position) {
        showCustomConfirmDialog(
            "删除记录",
            "确定要删除这条历史记录吗？",
            "删除",
            Color.parseColor("#EF4444"),
            new Runnable() {
                @Override
                public void run() {
                    HistoryManager.getInstance().deleteHistory(history.getId());
                    historyAdapter.removeItem(position);
                    
                    // 检查是否为空
                    if (HistoryManager.getInstance().getHistoryCount() == 0) {
                        emptyView.setVisibility(VISIBLE);
                        historyListView.setVisibility(GONE);
                    }
                    
                    UiUtils.showToast(getContext(), "已删除");
                }
            }
        );
    }
    
    /**
     * 显示清空全部对话框（美化版）
     */
    private void showClearAllDialog() {
        if (!HistoryManager.getInstance().hasHistories()) {
            UiUtils.showToast(getContext(), "没有可清空的历史记录");
            return;
        }
        
        showCustomConfirmDialog(
            "清空全部",
            "确定要清空所有历史记录吗？此操作不可恢复。",
            "清空",
            Color.parseColor("#EF4444"),
            new Runnable() {
                @Override
                public void run() {
                    HistoryManager.getInstance().clearAllHistories();
                    historyAdapter.clear();
                    emptyView.setVisibility(VISIBLE);
                    historyListView.setVisibility(GONE);
                    UiUtils.showToast(getContext(), "已清空全部历史记录");
                }
            }
        );
    }
    
    /**
     * 显示自定义确认弹窗
     */
    private void showCustomConfirmDialog(String title, String message, String confirmText, int confirmColor, final Runnable onConfirm) {
        final android.app.Dialog dialog = new android.app.Dialog(getContext(), android.R.style.Theme_Translucent_NoTitleBar);
        
        FrameLayout container = new FrameLayout(getContext());
        container.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        container.setBackgroundColor(Color.parseColor("#80000000"));
        
        LinearLayout content = new LinearLayout(getContext());
        FrameLayout.LayoutParams contentParams = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        contentParams.gravity = Gravity.CENTER;
        contentParams.leftMargin = UiUtils.dpToPx(getContext(), 32);
        contentParams.rightMargin = UiUtils.dpToPx(getContext(), 32);
        content.setLayoutParams(contentParams);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setBackgroundDrawable(UiUtils.createRoundRectDrawable(Color.WHITE, 16, getContext()));
        content.setPadding(
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 24),
            UiUtils.dpToPx(getContext(), 24)
        );
        
        // 标题
        TextView titleView = new TextView(getContext());
        titleView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        titleView.setText(title);
        titleView.setTextSize(18);
        titleView.setTextColor(COLOR_TEXT_PRIMARY);
        titleView.setGravity(Gravity.CENTER);
        content.addView(titleView);
        
        // 消息
        TextView msgView = new TextView(getContext());
        LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        msgParams.topMargin = UiUtils.dpToPx(getContext(), 12);
        msgView.setLayoutParams(msgParams);
        msgView.setText(message);
        msgView.setTextSize(14);
        msgView.setTextColor(COLOR_TEXT_SECONDARY);
        msgView.setGravity(Gravity.CENTER);
        content.addView(msgView);
        
        // 按钮区域
        LinearLayout btnLayout = new LinearLayout(getContext());
        LinearLayout.LayoutParams btnLayoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        btnLayoutParams.topMargin = UiUtils.dpToPx(getContext(), 24);
        btnLayout.setLayoutParams(btnLayoutParams);
        btnLayout.setOrientation(LinearLayout.HORIZONTAL);
        
        // 取消按钮
        Button cancelBtn = new Button(getContext());
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
            0,
            UiUtils.dpToPx(getContext(), 44),
            1
        );
        cancelParams.rightMargin = UiUtils.dpToPx(getContext(), 8);
        cancelBtn.setLayoutParams(cancelParams);
        cancelBtn.setText("取消");
        cancelBtn.setTextSize(14);
        cancelBtn.setTextColor(COLOR_TEXT_SECONDARY);
        cancelBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(
            Color.parseColor("#F3F4F6"), 12, getContext()));
        cancelBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        btnLayout.addView(cancelBtn);
        
        // 确认按钮
        Button confirmBtn = new Button(getContext());
        LinearLayout.LayoutParams confirmParams = new LinearLayout.LayoutParams(
            0,
            UiUtils.dpToPx(getContext(), 44),
            1
        );
        confirmParams.leftMargin = UiUtils.dpToPx(getContext(), 8);
        confirmBtn.setLayoutParams(confirmParams);
        confirmBtn.setText(confirmText);
        confirmBtn.setTextSize(14);
        confirmBtn.setTextColor(Color.WHITE);
        confirmBtn.setBackgroundDrawable(UiUtils.createRoundRectDrawable(confirmColor, 12, getContext()));
        confirmBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                onConfirm.run();
            }
        });
        btnLayout.addView(confirmBtn);
        
        content.addView(btnLayout);
        
        container.addView(content);
        dialog.setContentView(container);
        
        container.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        
        content.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                // 阻止事件传递
            }
        });
        
        // 显示动画
        content.setScaleX(0.8f);
        content.setScaleY(0.8f);
        content.setAlpha(0f);
        dialog.show();
        content.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(200)
            .setInterpolator(new android.view.animation.DecelerateInterpolator())
            .start();
    }
    
    /**
     * 继续历史对话
     */
    public void continueChat(ChatHistory history) {
        if (history == null) return;
        
        // 保存当前对话到历史（如果有）
        List<Message> currentMessages = DataStore.getInstance().getCurrentMessages();
        if (currentMessages != null && !currentMessages.isEmpty()) {
            HistoryManager.getInstance().archiveCurrentChat(
                history.getCharacterId(),
                history.getCharacterName(),
                new ArrayList<Message>(currentMessages)
            );
        }
        
        // 加载历史消息到当前对话
        DataStore.getInstance().saveCurrentMessages(new ArrayList<Message>(history.getMessages()));
        
        // 通知外部切换到聊天页
        if (selectListener != null) {
            selectListener.onHistorySelected(history);
        }
    }
    
    /**
     * 页面显示时调用
     */
    public void onShow() {
        loadHistories();
    }
}
