package com.samoai.ai.manager;

import com.samoai.ai.model.CharacterCard;
import com.samoai.ai.store.DataStore;

import java.util.ArrayList;
import java.util.List;

/**
 * 角色卡管理器
 */
public class CharacterManager {
    private static CharacterManager instance;
    private List<CharacterCard> characters;
    private CharacterCard currentCharacter;
    
    private CharacterManager() {
        loadCharacters();
        currentCharacter = DataStore.getInstance().getCurrentCharacter();
    }
    
    public static synchronized CharacterManager getInstance() {
        if (instance == null) {
            instance = new CharacterManager();
        }
        return instance;
    }
    
    /**
     * 加载角色卡列表
     */
    private void loadCharacters() {
        characters = DataStore.getInstance().getCharacters();
        if (characters == null) {
            characters = new ArrayList<CharacterCard>();
        }
    }
    
    /**
     * 获取所有角色卡
     */
    public List<CharacterCard> getCharacters() {
        return new ArrayList<CharacterCard>(characters);
    }
    
    /**
     * 获取当前角色卡
     */
    public CharacterCard getCurrentCharacter() {
        return currentCharacter;
    }
    
    /**
     * 设置当前角色卡
     */
    public void setCurrentCharacter(CharacterCard character) {
        this.currentCharacter = character;
        DataStore.getInstance().saveCurrentCharacter(character);
    }
    
    /**
     * 添加角色卡
     */
    public void addCharacter(CharacterCard character) {
        if (character != null) {
            characters.add(character);
            DataStore.getInstance().saveCharacters(characters);
        }
    }
    
    /**
     * 更新角色卡
     */
    public void updateCharacter(CharacterCard character) {
        if (character == null) return;
        
        for (int i = 0; i < characters.size(); i++) {
            if (characters.get(i).getId().equals(character.getId())) {
                characters.set(i, character);
                DataStore.getInstance().saveCharacters(characters);
                
                // 如果更新的是当前角色卡，同步更新
                if (currentCharacter != null && currentCharacter.getId().equals(character.getId())) {
                    currentCharacter = character;
                    DataStore.getInstance().saveCurrentCharacter(character);
                }
                break;
            }
        }
    }
    
    /**
     * 删除角色卡
     */
    public void deleteCharacter(String characterId) {
        for (int i = 0; i < characters.size(); i++) {
            if (characters.get(i).getId().equals(characterId)) {
                characters.remove(i);
                DataStore.getInstance().saveCharacters(characters);
                
                // 如果删除的是当前角色卡，清空当前角色卡
                if (currentCharacter != null && currentCharacter.getId().equals(characterId)) {
                    currentCharacter = null;
                    DataStore.getInstance().saveCurrentCharacter(null);
                }
                break;
            }
        }
    }
    
    /**
     * 根据ID获取角色卡
     */
    public CharacterCard getCharacterById(String id) {
        for (int i = 0; i < characters.size(); i++) {
            if (characters.get(i).getId().equals(id)) {
                return characters.get(i);
            }
        }
        return null;
    }
    
    /**
     * 获取默认角色卡（如果没有则创建一个）
     */
    public CharacterCard getDefaultCharacter() {
        if (currentCharacter != null) {
            return currentCharacter;
        }
        if (!characters.isEmpty()) {
            return characters.get(0);
        }
        // 创建默认角色卡
        CharacterCard defaultCard = new CharacterCard();
        defaultCard.setName("Samoai");
        defaultCard.setDescription("我是Samoai，可以陪你聊天，写代码。");
        defaultCard.setFirstMes("你好！我是Samoai，有什么可以帮助你的吗？");
        addCharacter(defaultCard);
        return defaultCard;
    }
    
    /**
     * 是否有角色卡
     */
    public boolean hasCharacters() {
        return !characters.isEmpty();
    }
    
    /**
     * 获取角色卡数量
     */
    public int getCharacterCount() {
        return characters.size();
    }
}
