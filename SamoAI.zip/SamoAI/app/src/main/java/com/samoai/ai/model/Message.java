package com.samoai.ai.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 聊天消息实体类
 */
public class Message {
    public static final int TYPE_USER = 0;
    public static final int TYPE_AI = 1;
    public static final int TYPE_SYSTEM = 2;
    
    private String id;
    private int type;
    private String content;
    private long timestamp;
    private boolean isStreaming;
    
    public Message() {
        this.id = String.valueOf(System.currentTimeMillis());
        this.timestamp = System.currentTimeMillis();
        this.isStreaming = false;
    }
    
    public Message(int type, String content) {
        this();
        this.type = type;
        this.content = content;
    }
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public int getType() {
        return type;
    }
    
    public void setType(int type) {
        this.type = type;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    public boolean isStreaming() {
        return isStreaming;
    }
    
    public void setStreaming(boolean streaming) {
        isStreaming = streaming;
    }
    
    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        try {
            json.put("id", id);
            json.put("type", type);
            json.put("content", content);
            json.put("timestamp", timestamp);
            json.put("isStreaming", isStreaming);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return json;
    }
    
    public static Message fromJson(JSONObject json) {
        Message message = new Message();
        try {
            message.setId(json.optString("id", String.valueOf(System.currentTimeMillis())));
            message.setType(json.optInt("type", TYPE_USER));
            message.setContent(json.optString("content", ""));
            message.setTimestamp(json.optLong("timestamp", System.currentTimeMillis()));
            message.setStreaming(json.optBoolean("isStreaming", false));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return message;
    }
}
