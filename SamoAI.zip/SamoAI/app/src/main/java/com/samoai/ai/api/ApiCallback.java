package com.samoai.ai.api;

/**
 * API请求回调接口
 */
public interface ApiCallback<T> {
    void onSuccess(T result);
    void onError(String error);
}
