package com.samoai.ai.utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.samoai.ai.model.CharacterCard;

/**
 * JSON验证工具类
 */
public class JsonValidator {
    
    /**
     * 验证是否为有效的JSON对象
     */
    public static boolean isValidJsonObject(String json) {
        if (json == null || json.trim().isEmpty()) {
            return false;
        }
        try {
            new JSONObject(json);
            return true;
        } catch (JSONException e) {
            return false;
        }
    }
    
    /**
     * 验证是否为有效的JSON数组
     */
    public static boolean isValidJsonArray(String json) {
        if (json == null || json.trim().isEmpty()) {
            return false;
        }
        try {
            new JSONArray(json);
            return true;
        } catch (JSONException e) {
            return false;
        }
    }
    
    /**
     * 验证是否为有效的SillyTavern角色卡（支持V1和V2格式）
     */
    public static boolean isValidSillyTavernCard(String json) {
        if (!isValidJsonObject(json)) {
            return false;
        }
        try {
            JSONObject obj = new JSONObject(json);
            return CharacterCard.isValidSillyTavernCard(obj);
        } catch (JSONException e) {
            return false;
        }
    }
    
    /**
     * 解析SillyTavern角色卡
     */
    public static CharacterCard parseSillyTavernCard(String json) {
        if (!isValidSillyTavernCard(json)) {
            return null;
        }
        try {
            JSONObject obj = new JSONObject(json);
            return CharacterCard.fromSillyTavernJson(obj);
        } catch (JSONException e) {
            return null;
        }
    }
    
    /**
     * 获取验证错误信息
     */
    public static String getValidationError(String json) {
        if (json == null || json.trim().isEmpty()) {
            return "文件内容为空";
        }
        if (!isValidJsonObject(json)) {
            return "无效的酒馆角色卡文件：不是有效的JSON格式";
        }
        try {
            JSONObject obj = new JSONObject(json);
            
            // V2格式检测
            if (obj.has("spec") && obj.has("data")) {
                String spec = obj.optString("spec", "");
                if (spec.contains("chara_card")) {
                    JSONObject data = obj.optJSONObject("data");
                    if (data == null) {
                        return "无效的酒馆角色卡文件：V2格式缺少data字段";
                    }
                    if (!data.has("name") || data.optString("name", "").isEmpty()) {
                        return "无效的酒馆角色卡文件：角色名称为空";
                    }
                    return null; // 验证通过
                }
            }
            
            // V1格式检测
            if (!obj.has("name")) {
                return "无效的酒馆角色卡文件：缺少角色名称";
            }
            String name = obj.optString("name", "");
            if (name.trim().isEmpty()) {
                return "无效的酒馆角色卡文件：角色名称为空";
            }
            return null; // 验证通过
        } catch (JSONException e) {
            return "无效的酒馆角色卡文件：" + e.getMessage();
        }
    }
}
