package com.samoai.ai.utils;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

/**
 * UI工具类
 */
public class UiUtils {
    
    /**
     * dp转px
     */
    public static int dpToPx(Context context, float dp) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, 
            dp, 
            context.getResources().getDisplayMetrics()
        );
    }
    
    /**
     * sp转px
     */
    public static int spToPx(Context context, float sp) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 
            sp, 
            context.getResources().getDisplayMetrics()
        );
    }
    
    /**
     * 获取屏幕宽度
     */
    public static int getScreenWidth(Context context) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return metrics.widthPixels;
    }
    
    /**
     * 获取屏幕高度
     */
    public static int getScreenHeight(Context context) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return metrics.heightPixels;
    }
    
    /**
     * 创建圆角矩形背景
     */
    public static GradientDrawable createRoundRectDrawable(int color, float radiusDp, Context context) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(color);
        drawable.setCornerRadius(dpToPx(context, radiusDp));
        return drawable;
    }
    
    /**
     * 创建圆角矩形背景（指定各角半径）
     */
    public static GradientDrawable createRoundRectDrawable(int color, float[] radii, Context context) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setColor(color);
        
        float[] pxRadii = new float[radii.length];
        for (int i = 0; i < radii.length; i++) {
            pxRadii[i] = dpToPx(context, radii[i]);
        }
        drawable.setCornerRadii(pxRadii);
        return drawable;
    }
    
    /**
     * 创建圆形背景
     */
    public static GradientDrawable createCircleDrawable(int color) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.OVAL);
        drawable.setColor(color);
        return drawable;
    }
    
    /**
     * 创建按压效果的选择器
     */
    public static StateListDrawable createPressedSelector(Drawable normal, Drawable pressed) {
        StateListDrawable selector = new StateListDrawable();
        selector.addState(new int[]{android.R.attr.state_pressed}, pressed);
        selector.addState(new int[]{}, normal);
        return selector;
    }
    
    /**
     * 显示Toast
     */
    public static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
    
    /**
     * 显示长Toast
     */
    public static void showLongToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }
    
    /**
     * 隐藏软键盘
     */
    public static void hideKeyboard(View view) {
        if (view == null) return;
        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
    
    /**
     * 显示软键盘
     */
    public static void showKeyboard(View view) {
        if (view == null) return;
        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
        }
    }
    
    /**
     * 设置视图背景（兼容各版本）
     */
    public static void setBackground(View view, Drawable drawable) {
        if (view == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            view.setBackground(drawable);
        } else {
            view.setBackgroundDrawable(drawable);
        }
    }
    
    /**
     * 颜色变暗
     */
    public static int darkenColor(int color, float factor) {
        int a = Color.alpha(color);
        int r = Math.round(Color.red(color) * factor);
        int g = Math.round(Color.green(color) * factor);
        int b = Math.round(Color.blue(color) * factor);
        return Color.argb(a, Math.min(r, 255), Math.min(g, 255), Math.min(b, 255));
    }
    
    /**
     * 颜色变亮
     */
    public static int lightenColor(int color, float factor) {
        int a = Color.alpha(color);
        int r = Math.round(Color.red(color) + (255 - Color.red(color)) * factor);
        int g = Math.round(Color.green(color) + (255 - Color.green(color)) * factor);
        int b = Math.round(Color.blue(color) + (255 - Color.blue(color)) * factor);
        return Color.argb(a, Math.min(r, 255), Math.min(g, 255), Math.min(b, 255));
    }
    
    /**
     * 格式化时间戳
     */
    public static String formatTime(long timestamp) {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault());
        return sdf.format(new java.util.Date(timestamp));
    }
    
    /**
     * 截断文本
     */
    public static String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength) + "...";
    }
}
