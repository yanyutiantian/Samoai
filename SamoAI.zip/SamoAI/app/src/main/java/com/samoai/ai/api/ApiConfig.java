package com.samoai.ai.api;

/**
 * API配置类
 */
public class ApiConfig {
    public static final String BASE_URL = "http:///v1";
    public static final String CHAT_COMPLETIONS = "/chat/completions";
    public static final String MODELS = "/models";
    public static final String BALANCE = "/credits";
    
    public static final int CONNECT_TIMEOUT = 30000;
    public static final int READ_TIMEOUT = 60000;
    public static final int WRITE_TIMEOUT = 30000;
}
