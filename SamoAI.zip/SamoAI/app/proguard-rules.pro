# ProGuard rules
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
