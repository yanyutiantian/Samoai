# SamoAI - Android AI聊天应用

## 项目简介

SamoAI是一款仿Kimi风格的Android AI聊天应用，纯Java代码构建UI，支持OpenAI兼容的流式聊天接口。

## 技术规格

- **包名**: com.samoai.ai
- **开发语言**: Java 7
- **最低SDK**: API 16 (Android 4.1)
- **目标SDK**: API 28 (Android 9.0)
- **UI构建**: 纯Java代码，无XML布局

## 功能特性

### 聊天页
- 左上角切换角色卡（自动归档当前对话）
- 右上角导入SillyTavern酒馆角色卡JSON
- 仿Kimi气泡布局，消息从下往上淡入+缩放动画
- 流式输出逐字显示，不闪烁不跳字
- 支持新建话题
- 长按消息可复制文本

### 历史记录页
- 列表显示历史记录（角色名、最后消息、时间）
- 点击可继续对话
- 支持删除单条、清空全部
- 列表滑动流畅，Item按压有反馈动画

### 我的页
- 显示API Key（中间打码）
- 修改API Key
- 模型列表加载和选择
- 显示账户余额（total_usage）
- 导出/导入全部数据（换机迁移）
- 版本号显示

## 接口配置

```
Base URL: http://api.0api.uno:3425/v1
聊天接口: /chat/completions (OpenAI兼容，流式输出)
模型列表: /models
余额接口: /balance
```

## 项目结构

```
com.samoai.ai/
├── MainActivity.java          # 主Activity，Tab切换管理
├── SamoAIApp.java             # Application入口
├── api/
│   ├── ApiCallback.java       # API回调接口
│   ├── ApiConfig.java         # API配置
│   ├── HttpClient.java        # HTTP客户端（流式请求）
│   └── StreamCallback.java    # 流式输出回调
├── adapter/
│   ├── CharacterAdapter.java  # 角色卡列表适配器
│   ├── HistoryAdapter.java    # 历史记录列表适配器
│   ├── MessageAdapter.java    # 消息列表适配器
│   └── ModelAdapter.java      # 模型列表适配器
├── manager/
│   ├── CharacterManager.java  # 角色卡管理
│   └── HistoryManager.java    # 历史记录管理
├── model/
│   ├── BalanceInfo.java       # 余额信息
│   ├── CharacterCard.java     # 角色卡实体
│   ├── ChatHistory.java       # 聊天历史
│   ├── Message.java           # 消息实体
│   └── ModelInfo.java         # 模型信息
├── store/
│   └── DataStore.java         # 本地数据存储
├── ui/
│   ├── ChatPage.java          # 聊天页面
│   ├── HistoryPage.java       # 历史记录页面
│   └── ProfilePage.java       # 我的页面
└── utils/
    ├── AnimUtils.java         # 动画工具
    ├── FileUtils.java         # 文件工具
    ├── JsonValidator.java     # JSON验证工具
    └── UiUtils.java           # UI工具
```

## 动画效果

1. **Tab切换**: 区域淡入淡出+横向平滑位移
2. **消息出现**: 从下往上淡入+小幅度缩放
3. **按钮点击**: 轻微按压缩放
4. **弹窗**: 从底部滑入弹出
5. **列表滚动**: 无卡顿、无抖动
6. **流式输出**: 逐字流畅渲染

## 编译运行

### 使用Android Studio
1. 打开项目目录
2. 等待Gradle同步完成
3. 点击Run运行

### 使用命令行
```bash
cd /mnt/okcomputer/output/SamoAI
./gradlew assembleDebug
```

APK输出路径: `app/build/outputs/apk/debug/app-debug.apk`

## 使用说明

1. 首次使用需要在我的页设置API Key
2. 可选择或导入角色卡进行对话
3. 切换角色卡时当前对话自动归档到历史记录
4. 支持导出数据备份和导入恢复

## 注意事项

- 应用使用HTTP协议，非HTTPS
- 需要网络权限和存储权限
- 所有数据本地存储，支持导出导入
- 角色卡仅支持SillyTavern格式JSON
